# Storage request checks

Author: Ankit Joshi

These small diagnostics explain the measured work behind Graphs 2, 4 and 5.
Keep them separate from the full paper matrix and synthetic previews.

| Check | What we did | What we found |
|---|---|---|
| Historical 10K comparison, August 23 | Added one new partition with one file to 10,000 existing partitions; three repetitions. | Athena MSCK recorded 430 LIST + 431 HEAD; Glue recorded 1 LIST + 1 GET; RTMSF recorded 1 HEAD. The old collector excluded HeadBucket. |
| Glue file count, September 24 | Appended one file to a partition with 101 or 501 files. | Glue GETs accessed all 102 or 502 files. LIST page size was 250, with 1 or 3 LISTs. |
| Glue layout, September 25 UTC | A and B each had five files; appended one file to A. Compared one-key and three-key layouts. | Both recorded 1 LIST + 6 GET + 1 HeadBucket. All five old A files were read again; no B reads were recorded. |
| Athena key order, September 25 UTC | Compared 100 tenant/day pairs in both directory orders; added one new tenant partition. | Day-first: 3 LIST + 4 HEAD. Tenant-first: 103 LIST + 104 HEAD. Zero observed GETs in both. |
| Integrated Graph 5, September 27 UTC | Ran RTMSF and Athena on the same 100 tenant/day pairs in both directory orders, one fresh trial per method/order. | RTMSF: 1 HEAD in either order. Athena: 3 LIST + 4 HEAD versus 103 LIST + 104 HEAD. All four exact catalog/query checks passed at 101 partitions/rows. |

The historical 430 was Athena's LIST count, not Glue's count or all API calls.
Its prefixes were two root listings, 11 date listings and 417 site listings.
One parent listing can reveal several bottom-level partition names. RTMSF's
end-to-end delay includes intentional coalescing; request work and freshness
are separate measurements.

For Glue, events selected the affected partition, but the crawler then read
every file within it in these tests. Logs reported classification. The precise
internal reason for each GET is not exposed. RTMSF's known-schema membership
check does not require that file inspection.

## Athena key-order result

The [September 27 integrated run](../evidence/graph5_20260927/SUMMARY.md)
reproduced the Athena counts below and measured RTMSF in both layouts. Its twelve
CloudWatch and CloudTrail component counts agree, and calibration matched 28/28
known requests after moving calibration past the activation wait. The earlier
0/7 calibration observations below remain part of the September 25 record.
This is still a small validation; repeated 1K/10K layout measurements are pending.

Same data, same change, Athena engine version 3 in `us-west-2`:

| Folder order | LIST | HEAD | GET | Total |
|---|---:|---:|---:|---:|
| `day/tenant` | 3 | 4 | 0 | 7 |
| `tenant/day` | 103 | 104 | 0 | 207 |

Athena listed the table root twice in both cases. It then listed **one day
folder** versus **101 tenant folders**, once each. The regular listings requested
1,000 items per page; one root probe requested one item. The HEADs returned
`NoSuchKey` for directory/marker paths; both repairs succeeded. Both final tables
had exactly **101 partitions and 101 query rows**, with matching file payloads.

Clarification checked September 26: both partition columns were defined in the
correct order, all 100 starting partitions were already registered, and each
MSCK result reported exactly one missing partition. Every recorded LIST used
`Delimiter="/"`, which groups keys into the next folder level (`CommonPrefixes`).
That listing strategy explains the separate requests for tenant folders.

S3 also supports listing full object keys without a delimiter. These 101 files
could fit within its 1,000-object page limit, although we did not measure that
alternative. The observed 103 LISTs are a property of this Athena traversal;
they are not a minimum that every partition-discovery implementation must pay.
See the [S3 listing API](https://docs.aws.amazon.com/AmazonS3/latest/API/API_ListObjectsV2.html)
and [Athena MSCK documentation](https://docs.aws.amazon.com/athena/latest/ug/msck-repair-table.html).

**Conclusion:** key order can make MSCK listing work grow with the number of
tenant folders. Partition count alone does not determine that work. This explains
why the earlier 10K experiment did not require 10K LISTs. Keep both outcomes as a
layout-sensitivity check; the primary graph layout stays unchanged.

[Counts CSV](../evidence/athena_layout_20260925/summary.csv) ·
[Listed prefixes CSV](../evidence/athena_layout_20260925/listed_prefixes.csv) ·
[Retained evidence](../evidence/athena_layout_20260925/)

## Procedure and reproduction

1. Fresh tables and buckets: `day=2026-09-25/tenant=t000000/` versus
   `tenant=t000000/day=2026-09-25/`. Same 100 tenant/day pairs and file payloads.
2. Register the starting partitions and verify all 100 query rows. Wait for
   bucket metrics activation and at least two complete quiet minutes.
3. Upload one file for tenant `t000100`, then run Athena MSCK. Confirm the new
   partition was absent before repair and present afterward. One run per order.
4. Collect CloudWatch HEAD/GET/LIST counts and CloudTrail LIST prefixes. Keep
   final query reads and cleanup outside measurement windows; verify 101 rows.

Reproduce against an existing experiment stack (100 partitions by default):

```sh
uv run --frozen --extra experiment python -m experiments.aws.check_athena_layout \
  --profile YOUR_PROFILE --expected-account YOUR_ACCOUNT \
  --stack YOUR_TESTFANDA_STACK
```

The retained bundle includes counts, listed prefixes, query and fixture records,
measurement windows, request evidence, frozen source and cleanup records. All 599
original artifact hashes verified. Temporary buckets and tables were deleted;
CloudTrail settings were restored without reported errors.

**Measurement limit:** one repetition per layout. CloudWatch and recorded
CloudTrail counts matched; every measured request was attributed to Athena.
GET zero is supported by the CloudWatch operation totals accounting for
`AllRequests` and no recorded GET events. CloudTrail calibration matched 0/7
requests in each bucket, so agreement does not establish complete accounting.
The earlier Glue checks also had incomplete calibration.

Local retained bundles: `gcheck-09250055-bbd7` and `layout-09250547-df11` under
`evidence/runs/`. The historical 10K archive is retained separately under
`articles/rtmsf_aws_poc/release/evidence/comparative-10000-20260823-*` in the workspace.

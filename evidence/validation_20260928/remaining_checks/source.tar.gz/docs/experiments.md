# AWS experiment plan

Ankit Joshi · updated September 27, 2026

This is the current protocol: **five graphs, one recovery table, and supporting
correctness checks**. AWS is the evaluated implementation; other clouds are later
work. The main layout and the core algorithm are unchanged.

| Output | Question | X | Y | Methods |
|---|---|---|---|---|
| Graph 1 | Does the catalog follow file creation/deletion? | Elapsed seconds | Expected/observed presence | RTMSF |
| Graph 2 | Does a bigger table require more storage work for one new partition? | 100, 1K, 10K, 100K partitions | HEAD + GET + LIST | RTMSF, Glue event crawler, Athena MSCK |
| Graph 3 | How long until the new partition is visible? | Same as Graph 2 | Seconds from each method's trigger | Same as Graph 2 |
| Graph 4 | Does a fuller existing partition require more storage work? | 1, 10, 100, 1K, 10K existing files | HEAD + GET + LIST | RTMSF, Glue event crawler |
| Graph 5 | Does folder order change storage work? | 100, 1K, 10K partitions | HEAD + GET + LIST, two layout panels | RTMSF, Athena MSCK |
| Table 1 | Does each crash boundary recover correctly? | Four cases | Verified outcomes / attempts | RTMSF |

Use three fresh repetitions for correctness/recovery/checks and five for each
comparison condition. Graphs 2 and 3 share trials. Each measurement trial gets a
fresh table and bucket. See [the runbook](aws.md) for execution and cleanup.

## Readiness

- [x] Graph 5 integrated into the experiment runner and CSV/report utility.
- [x] CSV separates layouts; totals and failures cannot mix their results.
- [x] Allow 100K main partitions and 10K files/layout partitions; query-result
  verification paginates beyond 100 pages. These limits are not completed tests.
- [x] All five synthetic previews generated and visually checked.
- [x] Local suite and independently extracted source: 280 tests pass.
- [x] Fresh integrated Graph 5 AWS validation at 100 partitions: 4/4 trials,
  12/12 request measurements, exact 101-partition/row checks, verified cleanup.
  [Real CSV, graph and evidence](../evidence/graph5_20260927/SUMMARY.md).
- [ ] Collect the repeated paper matrix in batches and resolve missing evidence.
- [ ] Replace manuscript simulations and stale claims with the current contract,
  five measured graphs, recovery/check tables and exact method definitions.

The paper matrix has **170 measurement trials**, plus lifecycle, recovery and
supporting checks. Two complete quiet minutes per measurement alone require at
least 340 minutes; seeding, initial crawls, work and collection take longer.
Do not use the old 85-minute pilot budget for the full matrix.

## Preview and retained evidence

[The dummy CSV](experiment_data_dummy.csv) and [its assumptions](experiment_results_dummy.json)
are examples, not measurements or validated predictions. The preview includes
500K points to demonstrate plotting; the current paper matrix stops at 100K.
Generate all five previews with the same utility used by the AWS runner:

```sh
uv run --frozen --extra experiment python -m experiments.figures \
  --csv docs/experiment_data_dummy.csv --results docs/experiment_results_dummy.json \
  --output-dir /tmp/rtmsf-graph-preview
```

PNG is for viewing; PDF is for the manuscript. One color identifies each method.
Request graphs use logarithmic axes, medians of complete per-repetition totals,
and min–max whiskers. Graph 3 uses linear seconds on Y. Graph 1 shows repetition
1, selected before running, and retains every trace in the CSV.

The [evidence index](../evidence/README.md) retains the September 22–25 pilots,
failures and follow-ups. Those runs used the then-current four-graph protocol;
the September 23 run had 53/54 usable request values, and all seven supporting
check types passed across follow-ups. Earlier flat-layout checks remain valid
historical evidence but are not an extra required paper graph. The separate
September 25 Athena key-order check motivates Graph 5; it does not replace the
new two-method repeated experiment. Procedures, request counts and conclusions
are in [storage request checks](storage-request-checks.md).

The September 27 integrated Graph 5 run measured RTMSF totals of **1 / 1**
and Athena totals of **7 / 207** for day-first / tenant-first at 100 starting
partitions. CloudWatch and CloudTrail agreed on all twelve component counts;
28/28 calibration requests were found. One repetition validates this new path,
not the larger repeated paper matrix.

## Graph CSV

[experiment_data_dummy.csv](experiment_data_dummy.csv) demonstrates the agreed
graph-data format. **All numbers in this example file are invented, not AWS
results or performance predictions.** The filename identifies it as dummy data.
It contains three lifecycle repetitions, five repetitions per comparison
condition, and selected timeline samples. No successful experiment is claimed.

The 12 columns, in order, are:

`graph`, `method`, `layout`, `measurement`, `x_axis_label`, `x_value`, `x_unit`,
`y_axis_label`, `y_value`, `y_unit`, `repetition`, `action_label`.

Each row identifies one graph point. Axis labels describe the numbers; `measurement`
identifies the series. Graphs are numbered **1–5**. **Table 1** reports recovery
separately and is generated from trial records; its results do not go in this CSV.
`action_label` supplies graph 1's upload/delete annotations, attached once to the
expected-presence point at the action time. It is blank elsewhere. `layout` is blank for Graphs 1–4 and
`day_first` or `tenant_first` for Graph 5. Legacy 11-column CSVs remain readable.

| Graph | Measurements kept | How to read |
|---|---|---|
| 1 | Expected/observed partition presence | Two series over time; four action labels explain what happened. |
| 2 | S3 HEAD, GET, LIST requests | Compare storage work as existing partition count increases. |
| 3 | `visibility_delay_s` only | One delay per method, partition count, and repetition. |
| 4 | S3 HEAD, GET, LIST requests | Compare storage work as files in the affected partition increase. |
| 5 | S3 HEAD, GET, LIST requests | Compare key orders using the same tenant/day pairs. |

Filter `graph`, `method`, then `layout` for Graph 5, and `measurement`.
Rows are ordered by graph, method, layout, measurement, numeric X value, then
repetition. Series order is expected → observed for graph 1 and HEAD → GET →
LIST for request graphs. Method/legend order is **RTMSF → Glue event-based crawler
→ Athena MSCK**; actual execution order rotates across repetitions. Graphs 2 and
4 each use one chart with a solid colored line per method on logarithmic axes.
Graph 5 uses two panels with shared X/Y axes and the same method colors.
The plotter sums HEAD + GET + LIST within matching graph/method/layout/X/repetition records.
Points show the median of available totals; thin whiskers show min–max where
repetitions differ. Any missing component makes that repetition's total unknown. Keep the
component rows in the CSV; no duplicate total rows are needed.

Graphs 2 and 3 use the same trials, matched by method, partition count, and
repetition. For graph 3 the runner calculates elapsed time from the method's
trigger to first observed visibility and writes that result as `y_value`.
Raw checkpoints, query checks, table paths, configuration, and failures stay in
the experiment's logs and retained evidence. The graph CSV has no run ID, status,
or diagnostic fields.

**Request collection for graphs 2, 4 and 5:** the default collector reads CloudWatch
`HeadRequests`, `GetRequests` and `ListRequests` (`Sum`, 60-second periods,
`BucketName` + `FilterId=trial`). Each measured trial owns its bucket. Activate
metrics 15 minutes before measuring, leave two complete quiet minutes after setup
reads/initial crawls, and keep trial buckets idle for the final 10-minute delivery
wait. Freeze `quiet_until` before final Athena verification or bucket cleanup.
The graph CSV contains counts; raw snapshots retain the bounds
and any zero inference. CloudWatch cannot filter by requester, so no other
clients may read these buckets during measurement. It remains best-effort.
The setup guard excludes the two-minute timestamp spill seen in the September 23
audit; it is an empirical precaution, not an AWS delivery guarantee.

**Earlier CloudTrail measurements and supporting evidence:**
[the collector](../src/experiments/aws/request_audit.py) uses explicitly enabled
[CloudTrail S3 data events](https://docs.aws.amazon.com/AmazonS3/latest/userguide/cloudtrail-logging-s3-info.html#cloudtrail-data-events) for trial buckets, with logs delivered to a separate bucket.
HEAD = `HeadObject`/`HeadBucket`; GET = `GetObject`; LIST = `ListObjects`/`ListObjectsV2`.
Earlier pilots logged both LIST APIs as `ListObjects` and had missing calibration
records. Current isolated-bucket runs calibrate after the 15-minute activation
wait, then exclude those reads from measurement. Match known calls, including
paginated LIST, by returned S3 request IDs; retain any missing coverage.

Filter by trial data bucket, requester identity, and recorded processing window;
exclude setup, query checks, log/results buckets, and bucket configuration calls.
Count recorded requests including retries; deduplicate CloudTrail `eventID`s and retain
`requestID`s. HEAD + GET + LIST is the selected read/list total, not every S3 API or total cloud cost.

[CloudTrail is designed for at-least-once delivery](https://aws.amazon.com/cloudtrail/faqs/),
but [delivery time is not guaranteed](https://docs.aws.amazon.com/awscloudtrail/latest/userguide/how-cloudtrail-works.html).
Retain raw events and the collection cutoff; reconcile late records before publishing.
[CloudWatch metrics](https://docs.aws.amazon.com/AmazonS3/latest/userguide/cloudwatch-monitoring.html)
are also best-effort, not complete accounting.
Report observed counts and any coverage limits; neither a quiet period nor a successful calibration proves exact completeness.

Unknown measurements must not become zero. Keep failed runs in the run report
and disclose missing results; graph summaries must show the actual sample count.
Use a blank `y_value` for an unavailable observation or measurement; plotting
leaves a gap and counts only available values when summarizing repetitions.

Each execution saves its configuration (sizes, file counts, repetitions, and
runtime settings) and its own graph CSV. Graph 5 keeps both layouts in that CSV,
identified by the `layout` column. Legacy flat-layout CSVs stay separate. Reproduction
uses the published code and that configuration; timings and timeline sample
counts may vary. Real runs retain individual trials, every poll, and the evidence
needed to verify the plotted results.

## Same layout for every main experiment

```text
orders/dt=2026-01-01/site=site-000/hour=00/part-000001.parquet
```

- **Three partition columns:** `dt`, `site`, `hour` (strings).
  Two data columns: `record_id`, `amount` (BIGINT).
- **Separate identical copies:** `orders_rtmsf_<trial>`,
  `orders_msck_<trial>`, `orders_crawler_<trial>`; separate buckets.
  Shared catalog tables would let one method change another's result.
- **Predictable growth:** fill hours 00–23, then sites 000–099, then advance
  the date. Start on 2026-01-01. The next unused combination is the new partition.
- **Same files:** valid Snappy Parquet, one row/file, copied byte-for-byte.
  Use fresh tables/prefixes per trial.

**Why this layout?** It is a familiar Hive-style layout for dated, site-specific
records. The full combination of date + site + hour identifies **one partition**;
that folder can contain many files. Three columns do not mean three partitions.
It makes the storage-to-catalog mapping easy to inspect and generates all table
sizes with one rule. RTMSF does not require these particular column names.

Every method gets the same layout and starting data. Folder structure can affect
discovery work, so the second-layout check below tests sensitivity to that choice.

## Graph 1. Does the catalog stay correct?

- **Start:** RTMSF only; empty `orders` table. Every action below targets the
  **same single partition**, `dt=2026-01-01/site=site-000/hour=00/`.
- **Do/check:** follow the table in order. Each file contains one row, so the
  expected query row count equals the remaining file count.
- **Wait:** finish processing that stage's notifications and pass its catalog
  and query checks before the next action. Record a timeout as a failed stage.
- **Plot:** X = time; expected and observed state are two step lines. Label
  the Y-axis **Absent / Present**; the CSV keeps 0/1 values. Poll Glue every
  second; check values, location, and schema too.

| Action in the same partition | Files left / expected query rows | Expected catalog presence after processing |
|---|---:|---|
| Upload the first file | 1 | 1 — present |
| Upload 4 more files | 5 | 1 — present |
| Delete 1 file | 4 | 1 — present |
| Delete all remaining 4 files | 0 | 0 — absent |

This checks that the first file registers the partition and only the last-file
deletion removes it. The numbers 1, 5, 4, 0 are file/row counts, not partitions.

**Data collection — agreed:**

- **Expected presence:** derive from successfully completed uploads/deletions:
  at least one file remains = 1; no files remain = 0.
- **Observed presence:** an independent observer calls Glue `GetPartition`
  about once per second: found = 1; confirmed absent = 0. API errors are unknown,
  never absence. Keep every poll from the pre-upload baseline through the final
  stage's completion, including unchanged states. Real runs have more points
  than the dummy CSV's selected samples; do not use its timestamps as a schedule.
- **Time and labels:** use actual action completion and observation times,
  relative to the first successful upload response. A negative time is a
  pre-upload baseline (the dummy CSV includes −1 second). Attach each action
  label to its expected-presence row. Actions and polls need not share timestamps.
  Draw state changes as steps and leave gaps where observations are unknown.
- **Evidence:** retain action results and Glue observations in the run logs.
  Athena query results check row counts separately; they do not supply this
  graph's presence values.

**Repetitions and presentation:** run the same four actions three times, using
fresh starting state for each repetition. This checks repeatable correctness
despite differences in event delivery and processing time. Keep every trace;
use repetition 1 for the figure, chosen before running, even if it fails. Report
the trace count in the caption and exact trial outcomes in `SUMMARY.md`; flag
any failed or incomplete trials on the figure.
Do not average binary states across repetitions. These four workload actions
cover this lifecycle illustration; no additional file counts or burst sweep
are needed for graph 1.

## Graph 2. Does a bigger table mean more storage work?

These trials also supply graph 3's delay measurements.

**Fresh tables for every size, method, and repetition.** The 1K case starts
with a new table containing 1K partitions; it does not grow the tested 100 case.
Each row below requires three identical starting copies, one per method.

| Size | Starting partitions in each table | Starting files in each table | Measured change per method | Expected final partitions |
|---|---:|---:|---|---:|
| 100 | 100 | 100 | Upload 1 file into 1 new partition | 101 |
| 1K | 1,000 | 1,000 | Upload 1 file into 1 new partition | 1,001 |
| 10K | 10,000 | 10,000 | Upload 1 file into 1 new partition | 10,001 |
| 100K | 100,000 | 100,000 | Upload 1 file into 1 new partition | 100,001 |

"One file each" means **one file inside every starting partition**.
The measured upload uses the next unused date/site/hour combination, absent
from both storage and Glue before the upload. For the 100-partition case:

```text
Last existing partition: orders/dt=2026-01-01/site=site-004/hour=03/
Upload the new file to:  orders/dt=2026-01-01/site=site-004/hour=04/part-000101.parquet
```

Uploading creates data at the new partition path; the tested method must register
that 101st partition in Glue. We do not register it during setup. Adding a file
to an already registered partition belongs to graph 4 and has no new visibility time.

For example, size 100, repetition 1 uses separate tables
`orders_rtmsf_p100_r1`, `orders_msck_p100_r1`, and `orders_crawler_p100_r1`,
with identical data in separate storage copies.

1. **Prepare:** create the fresh tables and baseline files; register all starting
   partitions. Finish the crawler's initial scan and drain setup events.
   Preparation is outside the measurements.
2. **Run one method at a time:** upload its new file, then poll its new partition
   in Glue every second, before starting either managed service.
   Each method gets its own upload and timestamps.
   Use graph 3's start points below rather than one shared upload-time origin.
3. **Apply the method:** follow the table below. Record actual event arrival and
   start times; no artificial scheduling delay is added.
4. **Measure both plots:** graph 2 counts S3 HEAD/GET/LIST requests for processing
   the change. Graph 3 stops timing when the new partition is first observed in Glue.
   Continue counting maintenance work after visibility until processing finishes.
   Both X-axes are the number of starting partitions.
5. **Repeat:** five fresh repetitions per size/method, rotating method order.
   Four sizes × three methods × five repetitions = **60 measured runs** for
   the main layout. The same 60 runs supply both graphs 2 and 3.

The normal RTMSF ADD path checks the new file with one HEAD; it needs no LIST.
Graph 4 appends to an existing partition, whose normal verification uses one LIST.

| Method | What happens after its upload |
|---|---|
| RTMSF | The worker is already running; it receives the S3 event and processes it using the fixed settling settings. |
| Athena MSCK | After the upload succeeds, the same script calls Athena `StartQueryExecution` with `MSCK REPAIR TABLE` as its next operation. Record the actual gap; it is not assumed to be zero. |
| Glue event-based crawler | Once the new S3 notification is available in its queue, the script starts the already initialized crawler for this method's table. |

**Why start an event-based crawler?** Events identify which folders to inspect;
their arrival does not itself start a crawl. AWS says that after the initial scan,
"you can choose to recrawl manually or on a set schedule."
Our script uses the manual/API option ([AWS event-crawler documentation](https://docs.aws.amazon.com/glue/latest/dg/crawler-s3-event-notifications.html)).

## Graph 3. Once triggered, how long until the partition is visible?

Use the same trials as graph 2. X = existing registered partitions;
Y = seconds from the method's stated trigger to first observed Glue visibility.
Poll independently while the method runs; do not wait for MSCK/crawler completion
before checking. Include API latency/retries, service queueing/startup, and
processing after the trigger.

**Start points:**

| Method | Trigger used as time zero | Delay included after that trigger |
|---|---|---|
| RTMSF | Successful upload response; the data change automatically generates its notification. | Notification delivery, worker receipt, settling, and catalog processing. |
| Athena MSCK | Immediately before `StartQueryExecution`, with the new file already uploaded. | API latency/retries, service queueing/startup, and processing up to visibility. |
| Glue event-based crawler | Immediately before `StartCrawler`, with the new notification already available. | API latency, service queueing/startup, and processing up to visibility. |

Label each method's trigger explicitly in the figure. These are method-specific
response times; they do not compare total freshness from a common file-arrival time
or include a production MSCK/crawler scheduling interval.

Use the runner's monotonic clock for durations; save wall-clock times, upload/API
timestamps, query IDs, and actual poll times for audit. Polling gives an observed
visibility time with approximately one-second sampling, not an exact change instant.

## Graph 4. Does a fuller partition mean more storage work?

- **Start:** 10K registered partitions using the shared layout;
  compare RTMSF and the event crawler. Use a fresh table/prefix for every
  file count, method, and repetition.
- **File counts:** 1, 10, 100, 1K, or 10K existing files in the first partition.
  Other partitions keep one file each. Finish crawler initialization and drain
  setup notifications.
- **Change/check:** append exactly one file to that partition; verify catalog
  membership stays correct and its query gains one row.
- **Plot:** X = files already in that partition; Y = S3 HEAD + GET + LIST
  requests, displayed as solid lines on logarithmic axes. Count maintenance work
  through processing completion; this partition
  already exists, so no appearance timer.
- **Repeat:** five times per file count/method: five counts × two methods × five
  repetitions = **50 measured runs**. Query checks are outside request counts.

## Graph 5. Does folder order change storage work?

- **Data:** use N tenant values on one day, one identical Parquet file per
  partition. Compare `day=2026-09-25/tenant=t000000/` with
  `tenant=t000000/day=2026-09-25/`. The same pairs and bytes appear in both.
- **Fresh copies:** N = 100, 1K, 10K; separate table/bucket for each layout,
  method and repetition. Register N starting partitions; finish setup first.
- **Change:** upload one file for the next unused tenant on the same day.
  Verify it was absent beforehand, then verify all N+1 exact catalog entries
  and query rows afterward. RTMSF stays running; trigger Athena MSCK after upload.
- **Measure:** same isolated CloudWatch HEAD/GET/LIST protocol as Graph 2.
  Two panels share X/Y scales; X = existing partitions, Y = total requests.
- **Repeat:** 3 sizes × 2 layouts × 2 methods × 5 repetitions = **60 trials**.
  Rotate method and layout order. Use `--graph5-only --layout-sizes 100 1000 10000`.

This exposes the effect of directory traversal without choosing an expensive
layout for the headline comparison. It measures Athena's implementation, not a
lower bound on what every MSCK implementation must do. RTMSF's expected ADD path
uses one HEAD for either order; the experiment must verify that expectation.
Do not extrapolate the separate 100-partition observation as measured larger data.

## Table 1. Does it recover after a crash?

Generate the recovery table automatically from four crash cases, with three
fresh repetitions each: **12 trials**. The
table answers whether recovery works at each boundary; no cumulative counters
or recovery time plot are required.

**One trial = empty → present → empty, with one deliberate crash:**

1. Start with a fresh empty table/prefix, no files, and no pending workload
   messages. Use the shared layout and one selected partition.
2. Upload one file. Inject the crash here for an ADD case. Wait for processing
   or recovery; verify registration, acknowledgement, and a query result of 1 row.
3. Delete that file. Inject the crash here for a DROP case. Wait for processing
   or recovery; verify removal, acknowledgement, and a query result of 0 rows.
4. Confirm the empty state and completed message handling, then start the next
   fresh trial. Preserve failures before cleanup; cleanup cannot turn a failed
   trial into a pass.

**Implemented automatic crash mechanism:** one runner controls the same RTMSF worker
program/container image for every case. Before each trial it configures the
target partition, ADD or DROP, selected crash point, and a unique trial marker.
The runner and Glue observer run outside the worker and survive its exit.

**Code separation — implemented:**

- `src/rtmsf/` contains the normal worker, PMCP, WOERA, AWS adapters, and startup.
  Normal startup does not read crash settings or manage crash markers.
- `src/experiments/aws/run.py` reads settings and coordinates execution.
  `workloads.py` contains fixtures and graph/recovery steps; `checks.py` contains
  supporting cases. `aws/runtime.py` handles worker control and queries;
  `evidence.py` saves the bundle. `src/experiments/figures.py` generates its CSV and reports.
  `aws/legacy_run.py` retains the earlier interface, outside the current runner's path.
- `src/experiments/aws/crash_worker.py` starts the real worker with experiment-only
  crash controls. Marker handling and deliberate process exits belong here.

The launcher reuses the same worker class and real PMCP/AWS implementations.
All four cases use it with different settings; normal `src/rtmsf/aws_app.py` startup
does not read fault configuration. Docker defaults to the production target;
the pilot's `--target experiment` image contains the launcher, with the runner
selecting normal startup for performance trials.

- **A — before processing:** after the selected event is received and buffered,
  before PMCP processes it.
- **B — after catalog change, before acknowledgement:** immediately after the
  selected Glue registration/removal call succeeds, while its message is still
  unacknowledged.

At the matching point, an experiment-only hook saves a durable crash record
in S3 outside table data (`_experiment/crash/<trial-id>.json`) and abruptly
exits the worker (`os._exit(86)`). ECS starts a
replacement using the same program/settings. The marker prevents another
injected crash; SQS redelivers the original message after its lease expires.
Operation selection ensures a DROP test does not crash during its initial ADD.
The runner selects these boundaries automatically; a timed external stop call
cannot reliably select the gap between the catalog change and acknowledgement.

**Table 1 template — Pending means not yet measured.** Observe the catalog
immediately after replay/recovery, before the next cycle step or cleanup.

| Crash case | Expected catalog after recovery | Observed catalog | Selected crash verified / attempted | Replayed and acknowledged / attempted | Passed / attempted |
|---|---|---|---|---|---|
| ADD — before processing | Registered | Pending | Pending | Pending | Pending |
| ADD — after registration, before acknowledgement | Registered | Pending | Pending | Pending | Pending |
| DROP — before processing | Absent | Pending | Pending | Pending | Pending |
| DROP — after removal, before acknowledgement | Absent | Pending | Pending | Pending | Pending |

**Data collection — agreed:** the runner saves one result per trial in the
existing experiment record; the report generator fills this table automatically.
Expected state comes from the case; observed state comes from independent Glue
lookups after recovery, before proceeding to the next step. Each row summarizes
all attempted repetitions. Report observed-state counts (registered, absent,
unknown) and verified/attempted counts for the checks; show failed and incomplete
trial counts alongside the table. Retain individual results. A skipped trial
is not an attempt; disclose fewer than the planned three attempts per case.

A pass requires evidence of the selected crash boundary and ECS exit/restart,
no overlapping workers, the same SQS message redelivered and acknowledged, and
correct catalog/query checks through the full cycle. Retain crash records, task
IDs/exit status, message IDs, acknowledgement results, and Glue/query responses.
Unresolved API errors or missing evidence make a result incomplete, never a pass.
Keep failed/incomplete trials visible in the summary and individual records.
No second graph CSV or manually entered success/failure values are needed.

**AWS result:** the September 23 rerun passed all four crash boundaries twice
(8/8), including same-message replay and acknowledgement and full catalog/query
cycles. The observer handled real transient connection failures during this run.
The three earlier failed observations remain in the September 22 evidence.

## Supporting correctness and recovery checks

These use the shared layout unless stated. Record outcomes in a small table.
The bounded pilot runs the seven main-layout checks below when its time budget
allows. Graph 5 supplies the required layout sensitivity experiment. Skipped conditions remain
not attempted, outside the attempted-trial denominator.

| Check | Exact actions |
|---|---|
| Short burst | One uploader sends 20 distinct files into one partition back-to-back; verify all 20 rows. |
| Long burst | Send 9 files at 0, 5, …, 40 seconds; verify progress at the buffering cap and all 9 final rows. Record actual arrivals. |
| Two tables | Alternate 30 uploads: 5 files × 3 partitions × 2 tables (`orders` and `returns`, same schema). Check correct routing. |
| Duplicate/old events | Replay a captured notification three times after settling. Separately replay an old CREATE after deletion and an old DELETE after recreation; check final state. |
| Rapid changes | Stop the worker; create/delete, then separately delete/recreate; restart. Record final state and any contract-permitted retries/dead letters. |
| Retryable failures | Inject two retryable catalog-call failures, then allow AWS calls and verify success. |
| Retry exhaustion | Fail the initial attempt plus five retries; verify durable dead-letter storage before acknowledgement, then successful replay with healthy calls. |

## Rules for every run

- Check locally, pilot on AWS, run the matrix, then reproduce from a clean checkout.
- For the full matrix, use three fresh repetitions for graph 1, recovery and
  supporting checks; use five per comparison condition in graphs 2–5. Set
  `--repetitions 5 --correctness-repetitions 3`; the first bounded pilot uses one.
  Rotate method order. Report individual
  results and median/range, retaining failures and contrary results.
  Reruns should support the same conclusions, not identical seconds;
  investigate disagreements.
- Drain setup events; finish crawler initialization before measurement.
  Exclude setup, uploads, observers, and query checks from maintenance counts.
  Record Glue/SQS calls separately; request savings alone do not prove cost savings.
- Record planned/actual actions and native/replayed events. Label injected
  failures explicitly. Compare observations with expected catalog state.
- Save code/image identity, dependencies, settings, inputs, timestamps,
  request records, assertions, and checksums. Publish provisioning, run,
  plotting, shutdown, and cleanup commands for another AWS account.

<details>
<summary>Fixed settings and implementation notes</summary>

Database: supplied during deployment; object prefix: `fixture/<run_id>/<table_name>/`.
The folder basename matches the table name because Glue's initial crawler can
use that basename to resolve the catalog target.
File ordinal gives `record_id`; `amount = 10 × record_id`.

One ARM64 ECS/Fargate worker: 0.25 vCPU, 512 MiB, `us-west-2`.
Settling Q=10 seconds, maximum buffering=31 seconds, SQS lease=180 seconds;
five retries after the initial attempt. Q is not an end-to-end latency promise.

Crawler: existing catalog-table target, `CRAWL_EVENT_MODE`, preserve known
schema and inherit it for partitions. Archive exact crawler settings and
selected/effective Athena engine versions.

Implemented crash hook: `os._exit(86)` after buffering/before PMCP or after successful
catalog change/before acknowledgement. Select one partition, operation, and
boundary per trial; a unique durable marker outside table data prevents another
injected crash on restart. Record task IDs and exit status. Disable fault
controls for performance runs.

The pilot implements Q=10, the event crawler, isolated request measurement,
independent visibility timing, four fault cases, and seven supporting checks.
Larger sizes and the full repeated matrix remain outstanding. Small AWS evidence
now covers lifecycle, all four crash boundaries, and CloudWatch graphs 2–4.
Keep old 10K evidence separate:
older code/settings; its crawler timer measured completion, not first visibility.

</details>

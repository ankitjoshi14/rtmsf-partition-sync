# RTMSF

[![CI](https://github.com/ankitjoshi14/rtmsf-partition-sync/actions/workflows/ci.yml/badge.svg)](https://github.com/ankitjoshi14/rtmsf-partition-sync/actions/workflows/ci.yml)
[![Python 3.12+](https://img.shields.io/badge/python-3.12%2B-blue)](pyproject.toml)
[![MIT License](https://img.shields.io/badge/license-MIT-green)](LICENSE)

**Real-Time Metadata Synchronization Framework**, by **Ankit Joshi**.

Object uploads and deletes can leave Hive-style catalog partitions out of sync
with storage. RTMSF uses object-store notifications to reconcile affected
partitions in configured, existing tables. It groups arrivals by partition and
checks storage before adding or dropping catalog entries.

## How it works

- **Routing** resolves object events to configured tables and partition values.
- **WOERA** coalesces partition events using a settling interval and maximum
  buffering deadline.
- **PMCP** verifies current storage and reconciles catalog state idempotently.

```text
ObjectEvent → routing → PartitionEvent → WOERA → PartitionIntent → PMCP
```

The core is provider-neutral Python. The included AWS adapter connects S3
notifications, SQS delivery, and S3/Glue operations; the reference deployment runs
one ECS/Fargate worker. Input remains unacknowledged until its work finishes or
terminal input is durably copied to the dead-letter queue. See the
[implementation contract](docs/contract.md) for ordering, retries and recovery.

## Quick start

Requires Python 3.12+ and [uv](https://docs.astral.sh/uv/getting-started/installation/).
Clone the repository, install the locked development dependencies, and run the
local tests:

```bash
git clone https://github.com/ankitjoshi14/rtmsf-partition-sync.git
cd rtmsf-partition-sync
uv sync --frozen --extra dev
uv run --frozen --extra dev pytest -q
```

Local tests use fakes and SDK stubs; no AWS account is needed. CI runs these tests
on Python 3.12 and builds the source and wheel distributions.

For the worker alone, install `.[aws]` and run `python -m rtmsf.aws_app` with the
configuration in the contract. Importing the core does not require an AWS SDK.

## Reproduce on AWS

Follow [the AWS runbook](docs/aws.md) to build this checkout, deploy a fresh stack,
and run the bounded [five-graph AWS pilot](docs/experiments.md). It compares
RTMSF, the Glue event-based crawler, and Athena MSCK, and includes four crash
boundaries. Start with one repetition and small partition counts; the paper matrix uses
up to 100K main-layout partitions and 10K layout-check partitions in separate
batches. These targets are not completed measurements.
The distribution includes separate `rtmsf` and `experiments` packages. Run AWS
experiments from the checkout so each run can archive its source. The production
Docker image contains only `rtmsf`; the experiment image adds the fault launcher.

Configure the sizes and repetitions, then run `experiments.aws.run`. It creates
fresh tables and prefixes, checks query results with Athena, and saves one bundle:
graph CSV, five PNG/PDF figures, recovery/check tables, and supporting records.
Graphs 2 and 4 compare HEAD + GET + LIST totals using solid lines on logarithmic axes;
Graph 5 compares day/tenant and tenant/day layouts in two panels.
Buckets isolate measurements and do not create separate figures. Missing request
measurements stay blank; recorded counts are best-effort observations. Unexecuted
supporting checks remain marked not attempted. Docker builds default to normal
production startup; the pilot uses `--target experiment` for its fault launcher.
During measured RTMSF phases, catalog changes come from the worker. AWS runs
require your own account and incur resource charges; cleanup and retained data
are documented in the runbook.

## Evidence and limits

The [September 27 Graph 5 validation](evidence/graph5_20260927/SUMMARY.md)
passed all four trials at 100 starting partitions. RTMSF made one HEAD request
and no GET/LIST requests in either folder order; Athena's totals were 7 for
day/tenant and 207 for tenant/day. All final catalogs and queries had exactly 101 partitions
and rows. The [CSV](evidence/graph5_20260927/graph_data.csv) and figures regenerate
offline; one repetition per condition does not establish scaling behavior.

The [2026-09-23 review follow-up](evidence/README.md) generated four figures,
a graph CSV, and recovery/check tables at up to 1,000 starting partitions.
Both lifecycle trials, all eight crash trials, and all 18 attempted comparison
workload checks passed; 53 of 54 request measurements are usable. One GET value
overlapped delayed setup reads and remains blank. All seven supporting check
types have passed across the follow-up runs. Six additional flat-layout trials
passed, with all 18 request values corroborated by CloudTrail. Earlier failed
observations and historical Q=6-second results remain available.

Plot inputs, figures, source snapshots, and selected raw observations are included
in the repository; full unfiltered bundles remain local and ignored by Git.
Conditions have one or two completed repetitions; skipped repetitions remain
visible. This bounded validation does
not establish complete scaling behavior or timing distributions.

This implementation evaluates one worker and Parquet files in a configured
Hive-style layout. Convergence depends on retained notifications, valid routing,
and eventual provider availability. Storage checks and catalog writes are not
atomic with external writers. Multi-worker deployment and other cloud adapters
are not validated here. The contract states the operational boundaries and
retry policy.
See [related work](docs/related-work.md) for overlapping systems and claim boundaries.

## Repository layout

```text
src/rtmsf/            # Framework, AWS adapters and aws_app launcher
src/experiments/      # Shared graph generation and evidence files
src/experiments/aws/  # AWS runner, workloads, measurement and deployment
tests/               # Local checks
docs/                # Contract and reproduction instructions
evidence/            # Retained results
```

Run AWS experiments with `python -m experiments.aws.run`; regenerate figures
with `python -m experiments.figures`. Another implemented cloud would get a
sibling of `src/experiments/aws/` and produce the same graph CSV format.

| Path | Purpose |
|---|---|
| `src/rtmsf/` | Data models, routing, WOERA, PMCP and worker |
| `src/rtmsf/models.py` | Immutable event, table, partition, intent and result values |
| `src/rtmsf/interfaces.py` | Storage, catalog, event-source and telemetry interfaces |
| `src/rtmsf/adapters/aws.py` | Implementations: `SqsEventSource`, `S3ObjectStore`, `GluePartitionCatalog`, `JsonTelemetry` |
| `tests/` | Deterministic contract, failure/replay, adapter and evidence checks |
| `src/rtmsf/aws_app.py` | Configure and start the normal AWS worker |
| `src/experiments/aws/deploy.py`, `template.yaml` | Disposable AWS fixture deployment |
| `src/experiments/aws/run.py` | Command: settings, execution order, cleanup and final reports |
| `src/experiments/aws/workloads.py` | Fresh fixtures and the steps for five graphs and crash recovery |
| `src/experiments/aws/checks.py` | Supporting burst, replay, routing and retry workloads |
| `src/experiments/aws/runtime.py` | AWS clients, worker start/stop, Athena queries and runtime observations |
| `src/experiments/evidence.py` | Save bundle files and record the source used |
| `src/experiments/aws/crawler.py` | Configure and run the Glue event-based baseline |
| `src/experiments/aws/trial_buckets.py` | Separate measurement buckets and their cleanup |
| `src/experiments/aws/request_metrics.py` | Read CloudWatch request counts; `request_audit.py` cross-checks CloudTrail |
| `src/experiments/aws/check_request_metrics.py` | Standalone counter calibration |
| `src/experiments/aws/crash_worker.py` | Experiment-only faults around the real worker |
| `src/experiments/aws/legacy_run.py` | Historical small workloads and RTMSF/MSCK comparison |
| `src/experiments/figures.py` | Graph CSV, PNG/PDF figures, recovery/check tables, offline regeneration |
| `src/experiments/legacy_reports.py` | Historical small-run summary formatting |
| `docs/` | Implementation contract and AWS reproduction guide |
| `evidence/` | Accepted result index and CSV; raw local runs are ignored by Git |

The interfaces in `src/rtmsf/interfaces.py` have these implementations in
`src/rtmsf/adapters/aws.py`:

| Interface | Implementation |
|---|---|
| `EventSource` | `SqsEventSource` |
| `ObjectStore` | `S3ObjectStore` |
| `PartitionCatalog` | `GluePartitionCatalog` |
| `TelemetrySink` | `JsonTelemetry` |

Implementations declare their interfaces explicitly, for example
`class S3ObjectStore(ObjectStore)`. Python uses the class's base list where Java
would use `implements`. Related AWS classes stay together in `adapters/aws.py`.
`src/rtmsf/aws_app.py` creates them and connects them to the worker. Another cloud can
implement the same interfaces without changing routing, WOERA or PMCP.
The current runner uses shared experiment helpers directly; `aws/legacy_run.py`
retains the earlier runner. The `check_*` commands are focused diagnostics.

The earlier interactive simulator and analytical benchmark remain recoverable at
Git revision `501c4b1`. They are not the maintained implementation or live-cloud
evidence for this version.

## Contributing

Report bugs and propose focused changes through
[GitHub issues](https://github.com/ankitjoshi14/rtmsf-partition-sync/issues).
Include the revision, a minimal reproduction, and expected versus observed
behavior. Run the local tests before opening a pull request; describe validation
and any changes to the contract or evidence claims.

## Citation and license

Use [CITATION.cff](CITATION.cff) to cite the software. RTMSF is authored by
Ankit Joshi and released under the [MIT License](LICENSE).

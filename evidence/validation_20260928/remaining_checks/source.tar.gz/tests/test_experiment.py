import json
from pathlib import Path

import pytest


def partition(location="s3://fixture/root/dt=2026-09-10/site=a/hour=00/", kind="bigint"):
    return {"Values": ["2026-09-10", "a", "00"], "StorageDescriptor": {"Location": location, "Columns": [{"Name": "record_id", "Type": kind}], "InputFormat": "parquet.input", "OutputFormat": "parquet.output", "SerdeInfo": {"SerializationLibrary": "parquet.serde", "Parameters": {}}}}


def test_exact_catalog_assertion_rejects_location_schema_and_extra_partition():
    from experiments.aws.legacy_run import assert_catalog

    assert_catalog([partition()], [partition()])
    for actual in ([partition("s3://wrong/")], [partition(kind="string")], [], [partition(), partition() ]):
        with pytest.raises(AssertionError):
            assert_catalog(actual, [partition()])


def test_query_assertion_compares_rows_not_only_count():
    from experiments.aws.legacy_run import assert_rows

    assert_rows([["1", "10"]], [["1", "10"]])
    with pytest.raises(AssertionError):
        assert_rows([["1", "99"]], [["1", "10"]])


def test_fixture_locations_match_native_msck_directory_format():
    from experiments.aws.legacy_run import SmallRun

    run = object.__new__(SmallRun)
    run.tables = {method: {"StorageDescriptor": {"Location": "s3://fixture/root/"}} for method in ("rtmsf", "msck")}
    values = ("2026-09-10", "new", "0000")
    location = "s3://fixture/root/dt=2026-09-10/site=new/hour=0000"
    assert run.partition("rtmsf", values)["StorageDescriptor"]["Location"] == location + "/"
    assert run.partition("msck", values)["StorageDescriptor"]["Location"] == location


def test_evidence_bundle_refuses_overwrite_and_seals_hashes(tmp_path):
    from experiments.aws.legacy_run import EvidenceBundle

    bundle = EvidenceBundle(tmp_path / "run", {"run_id": "run"})
    bundle.write("snapshots/initial.json", {"partitions": []})
    with pytest.raises(FileExistsError):
        bundle.write("snapshots/initial.json", {})
    with pytest.raises(FileExistsError):
        EvidenceBundle(tmp_path / "run", {})
    bundle.seal({"status": "passed"})
    hashes = json.loads((tmp_path / "run" / "artifact-hashes.json").read_text())
    assert "manifest.json" in hashes and "snapshots/initial.json" in hashes
    assert len(hashes["summary.json"]) == 64


def test_run_paths_are_isolated_and_cannot_escape_fixture():
    from experiments.aws.legacy_run import fixture_identity

    first = fixture_identity("run_20260910_a")
    second = fixture_identity("run_20260910_b")
    assert first != second
    assert first["root"] == "fixture/run_20260910_a/"
    with pytest.raises(ValueError):
        fixture_identity("../production")


def test_report_keeps_unknown_msck_requests_unavailable():
    from experiments.legacy_reports import comparison_row

    row = comparison_row({"method": "msck", "catalog_visibility_seconds": 1.5, "method_seconds": 1.0})
    assert row["internal_storage_requests"] is None
    assert row["internal_catalog_requests"] is None


def test_nonempty_dlq_invalidates_success():
    from experiments.aws.legacy_run import assert_empty_dlq

    assert_empty_dlq({"ApproximateNumberOfMessages": "0", "ApproximateNumberOfMessagesNotVisible": "0"})
    with pytest.raises(AssertionError, match="dead-letter"):
        assert_empty_dlq({"ApproximateNumberOfMessages": "1", "ApproximateNumberOfMessagesNotVisible": "0"})


def test_delete_cannot_touch_an_unowned_object():
    from experiments.aws.legacy_run import SmallRun

    run = object.__new__(SmallRun)
    run.identity = {"root": "fixture/run_a/"}
    run.inputs = []
    with pytest.raises(ValueError, match="outside"):
        run.delete("fixture/run_b/part.parquet", 1)
    with pytest.raises(ValueError, match="outside"):
        run.delete("fixture/run_a/not_created_here.parquet", 1)


def test_failed_log_collection_still_preserves_inputs_lifecycle_and_api_calls(tmp_path):
    from experiments.aws.legacy_run import EvidenceBundle, SmallRun

    class Logs:
        def filter_log_events(self, **kwargs):
            raise RuntimeError("logs unavailable")

    class Sqs:
        def get_queue_attributes(self, **kwargs):
            return {"Attributes": {"ApproximateNumberOfMessages": "0", "ApproximateNumberOfMessagesNotVisible": "0"}}

    run = object.__new__(SmallRun)
    run.bundle = EvidenceBundle(tmp_path / "run", {})
    run.outputs = {"LogGroupName": "logs", "DeadLetterQueueUrl": "dlq"}
    run.start_ms = 0
    run.clients = {"logs": Logs(), "sqs": Sqs()}
    run.phases, run.inputs, run.lifecycle, run.operations = [], [{"key": "fixture/a"}], [{"event": "worker_stopped"}], [{"action": "PutObject"}]
    with pytest.raises(RuntimeError, match="logs unavailable"):
        run.collect()
    for name in ("input-manifest.json", "worker-lifecycle.json", "harness-api-operations.json"):
        assert (run.bundle.root / name).exists()


def test_crash_evidence_requires_exit86_and_nonoverlapping_successor():
    from experiments.aws.legacy_run import assert_crash_trace

    crashed = {"taskArn": "old", "stoppedAt": 2, "containers": [{"name": "worker", "exitCode": 86}]}
    restarted = {"taskArn": "new", "startedAt": 3}
    assert_crash_trace([crashed], [restarted])
    with pytest.raises(AssertionError):
        assert_crash_trace([], [restarted])
    with pytest.raises(AssertionError):
        assert_crash_trace([crashed], [{"taskArn": "new", "startedAt": 1}])
    with pytest.raises(AssertionError):
        assert_crash_trace([crashed], [restarted, {"taskArn": "another", "startedAt": 4}])


def test_api_counting_deduplicates_log_records_but_preserves_real_attempts():
    from experiments.aws.runtime import runtime_operations

    record = {"cloudwatch_event_id": "same", "record": {"component": "aws_adapter", "action": "api_call", "operation": "S3.HeadObject", "attempts": 2, "timestamp": "2026-09-10T00:00:05+00:00"}}
    another = {"cloudwatch_event_id": "second", "record": {**record["record"], "attempts": 1}}
    phases = [{"phase": "maintenance-rtmsf", "at": "2026-09-10T00:00:00+00:00"}, {"phase": "maintenance-msck", "at": "2026-09-10T00:00:10+00:00"}]
    operations, counts = runtime_operations([record, record, another], phases)
    assert len(operations) == 2
    assert counts["rtmsf_comparison"]["S3.HeadObject"] == 3


def test_deployed_timing_must_match_reported_configuration():
    from experiments.aws.legacy_run import validate_timing

    correct = {"SETTLING_MS": "10000", "MAXIMUM_MS": "31000", "QUEUE_VISIBILITY_SECONDS": "180"}
    validate_timing(correct)
    with pytest.raises(ValueError, match="timing"):
        validate_timing({**correct, "SETTLING_MS": "1000"})


def test_stopped_worker_waits_for_new_configuration_before_scaling(monkeypatch):
    from experiments.aws import legacy_run as run_small

    run = object.__new__(run_small.SmallRun)
    run.timeout, run.task_definition = 30, "new"
    stopped = {"pendingCount": 0, "runningCount": 0}
    states = [
        {**stopped, "taskDefinition": "old", "deployments": [{"taskDefinition": "old"}]},
        {**stopped, "taskDefinition": "new", "deployments": [{"taskDefinition": "new"}, {"taskDefinition": "old"}]},
        {**stopped, "taskDefinition": "new", "deployments": [{"taskDefinition": "new"}]},
    ]
    run.service = lambda: states.pop(0)
    monkeypatch.setattr(run_small.time, "sleep", lambda seconds: None)
    assert run.wait_worker(False, configured=True)["taskDefinition"] == "new"
    assert not states


@pytest.mark.parametrize("status", ["CREATE_IN_PROGRESS", "UPDATE_IN_PROGRESS"])
def test_incomplete_stack_blocks_run_before_fixture_mutation(status):
    from experiments.aws.legacy_run import validate_stack_status

    with pytest.raises(ValueError, match="wait for stack update to complete"):
        validate_stack_status(status)
    validate_stack_status("CREATE_COMPLETE")
    validate_stack_status("UPDATE_COMPLETE")


@pytest.mark.parametrize("crash", [False, True])
def test_legacy_runner_selects_explicit_launcher_and_target_fault(tmp_path, crash):
    from experiments.aws.legacy_run import EvidenceBundle, SmallRun
    from tests.test_aws_adapters import Client

    container = {
        "name": "worker", "image": "repo@sha256:abc", "entryPoint": ["old-launcher"],
        "environment": [
            {"name": "SETTLING_MS", "value": "10000"},
            {"name": "MAXIMUM_MS", "value": "31000"},
            {"name": "QUEUE_VISIBILITY_SECONDS", "value": "180"},
            {"name": "RTMSF_EXPERIMENT_CRASH_MARKER_KEY", "value": "obsolete"},
            {"name": "RTMSF_EXPERIMENT_FAULT", "value": "obsolete"},
        ],
    }
    ecs = Client(describe_task_definition=[{"taskDefinition": {"family": "test", "containerDefinitions": [container]}}], register_task_definition=[{"taskDefinition": {"taskDefinitionArn": "new"}}])
    run = object.__new__(SmallRun)
    run.run_id = "run_test"
    run.identity = {"rtmsf": "isolated"}
    run.outputs = {"EcrRepositoryUri": "repo", "GlueDatabaseName": "db", "DataBucketName": "data-bucket", "ClusterName": "cluster", "ServiceName": "service"}
    run.clients = {"ecs": ecs}
    run.bundle = EvidenceBundle(tmp_path / "run", {})
    run.service = lambda: {"taskDefinition": "old"}
    run.require_worker_stopped = lambda: None
    run.wait_worker = lambda *args, **kwargs: None
    run.configure_worker(crash=crash)
    configured = ecs.calls["register_task_definition"][0]["containerDefinitions"][0]
    env = {item["name"]: item["value"] for item in configured["environment"]}
    assert configured["entryPoint"] == ["python", "-m", "experiments.aws.crash_worker" if crash else "rtmsf.aws_app"]
    assert "RTMSF_EXPERIMENT_CRASH_MARKER_KEY" not in env
    if crash:
        fault = json.loads(env["RTMSF_EXPERIMENT_FAULT"])
        assert fault["operation"] == "ADD"
        assert fault["point"] == "before_processing"
        assert fault["partition_path"] == "dt=2026-09-10/site=replay/hour=0000"
        assert fault["table_id"] == "db.isolated"
    else:
        assert "RTMSF_EXPERIMENT_FAULT" not in env
def test_query_verification_reads_beyond_one_hundred_pages():
    from types import SimpleNamespace
    from experiments.aws.runtime import AwsRuntime

    calls = []
    def page(**request):
        index = int(request.get('NextToken', 0))
        calls.append(index)
        return {'ResultSet': {'Rows': [{'Data': [{'VarCharValue': str(index)}]}]},
                **({'NextToken': str(index + 1)} if index < 100 else {})}
    runtime = AwsRuntime.__new__(AwsRuntime)
    runtime.clients = {'athena': SimpleNamespace(
        start_query_execution=lambda **kwargs: {'QueryExecutionId': 'query'},
        get_query_execution=lambda **kwargs: {'QueryExecution': {'Status': {'State': 'SUCCEEDED'}}},
        get_query_results=page)}
    runtime.outputs = {'GlueDatabaseName': 'db', 'AthenaWorkGroupName': 'wg', 'AthenaResultsBucketName': 'results'}
    runtime.timeout, runtime.run_id, runtime.queries = 600, 'test', []
    runtime.bundle = SimpleNamespace(write=lambda *args: None)
    rows, record = runtime.query('SELECT * FROM example', 'large-verification')
    assert calls == list(range(101)) and len(rows) == 101
    assert record['rows'] == rows

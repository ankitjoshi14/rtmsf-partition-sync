"""Small-run summary records with explicit measurement limits."""
from __future__ import annotations

import csv
from io import StringIO


def comparison_row(record: dict) -> dict:
    return {
        "method": record["method"],
        "catalog_visibility_seconds": record["catalog_visibility_seconds"],
        "method_seconds": record.get("method_seconds"),
        "internal_storage_requests": record.get("storage_request_attempts") if record["method"] == "rtmsf" else None,
        "internal_catalog_requests": record.get("catalog_request_attempts") if record["method"] == "rtmsf" else None,
        "request_coverage": "worker application telemetry collected separately" if record["method"] == "rtmsf" else "MSCK internal requests unavailable; Athena execution metadata only",
    }


def render_summary(summary: dict) -> str:
    lines = ["# Small AWS contract experiment", "", f"Status: **{summary['status']}**", "", "Native S3 notifications drive RTMSF. MSCK is an ADD-only baseline.", "", "Upload-to-catalog observations include upload and observer polling. Query results are checked afterward; they are not query-visibility latency measurements.", ""]
    for item in summary.get("comparisons", []):
        lines.append(f"- {item['method']}: catalog observed after {item['catalog_visibility_seconds']:.3f} s; exact catalog and query checks passed.")
    for item in summary.get("correctness", []):
        lines.append(f"- {item['scenario']}: catalog and query checks passed ({item['rows']} expected rows).")
    if summary.get("error"):
        lines.extend(["", f"Failure: {summary['error']}"])
    lines.extend(["", "Raw harness API calls, runtime logs, task/image identity, snapshots, input hashes, query IDs/results, and phase timestamps are retained. Worker request attempts must be read from runtime telemetry. Unknown MSCK internal requests are unavailable, never zero.", "", "This small run does not establish scalability, p95 latency, multi-worker safety, or provider portability.", ""])
    return "\n".join(lines)


def comparison_csv(records: list[dict]) -> str:
    rows = [comparison_row(record) for record in records]
    if not rows:
        return ""
    output = StringIO()
    writer = csv.DictWriter(output, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
    return output.getvalue()

"""Measure Athena MSCK with day/tenant versus tenant/day; author: Ankit Joshi."""
import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import tarfile
import time
from types import SimpleNamespace
from urllib.parse import unquote_plus
import uuid

from experiments.aws.deploy import validate_target
from experiments.aws.request_metrics import wait_until
from experiments.evidence import EvidenceBundle, source_snapshot, utc
from experiments.aws.request_audit import RequestAudit
from experiments.aws.request_metrics import RequestMetrics
from experiments.aws.trial_buckets import TrialBuckets
from experiments.aws.workloads import Pilot


class AthenaLayoutPilot(Pilot):
    """Only the two partition-key orders differ from the shared pilot."""

    @property
    def keys(self):
        return ('day', 'tenant') if self.args.layout == 'day_first' else ('tenant', 'day')

def write_csv(path, rows):
    if not rows:
        return
    with path.open('x', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def prepare(pilot, name, count):
    fixture = pilot.fixture(name, 'athena_msck', base=0)
    table = fixture['table']
    table['PartitionKeys'] = [{'Name': key, 'Type': 'string'} for key in pilot.keys]
    pilot.clients['glue'].update_table(DatabaseName=pilot.outputs['GlueDatabaseName'], TableInput=table)
    for index in range(count):
        values = pilot.values(index)
        descriptor = deepcopy(table['StorageDescriptor'])
        descriptor['Location'] += pilot.path(values)
        fixture['partitions'][values] = dict(Values=list(values), StorageDescriptor=descriptor)
    with ThreadPoolExecutor(max_workers=8) as pool:
        list(pool.map(lambda index: pilot.upload(fixture, pilot.values(index), index), range(count)))
    partitions = list(fixture['partitions'].values())
    for offset in range(0, count, 100):
        response = pilot.clients['glue'].batch_create_partition(DatabaseName=pilot.outputs['GlueDatabaseName'],
            TableName=table['Name'], PartitionInputList=partitions[offset:offset + 100])
        if response.get('Errors'):
            raise RuntimeError(f'Initial partition registration failed: {response["Errors"]}')
    pilot.record('layout_fixture_ready', table=table, starting_partitions=count,
                 first_level_folders=len({pilot.values(i)[0] for i in range(count)}))
    pilot.verify(fixture, name + '_baseline')
    return fixture


def main():
    import boto3
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--profile', required=True)
    parser.add_argument('--expected-account', required=True)
    parser.add_argument('--stack', required=True)
    parser.add_argument('--region', default='us-west-2')
    parser.add_argument('--partitions', type=int, default=100)
    args = parser.parse_args()
    if not 1 <= args.partitions <= 1000:
        parser.error('This diagnostic is limited to 1..1000 starting partitions')
    session = boto3.Session(profile_name=args.profile, region_name=args.region)
    validate_target(session.client('sts').get_caller_identity()['Account'], args.expected_account, args.stack, args.region)
    stack = session.client('cloudformation').describe_stacks(StackName=args.stack)['Stacks'][0]
    if stack['StackStatus'] not in ('CREATE_COMPLETE', 'UPDATE_COMPLETE'):
        raise RuntimeError('Experiment stack is not ready')
    outputs = {item['OutputKey']: item['OutputValue'] for item in stack['Outputs']}
    run_id = 'order-' + time.strftime('%m%d%H%M', time.gmtime()) + '-' + uuid.uuid4().hex[:4]
    root = Path('evidence/runs') / run_id
    bundle = EvidenceBundle(root, dict(author='Ankit Joshi', started_at=utc(), config=vars(args), outputs=outputs,
        design='Same tenant/day pairs and Parquet payloads; swap key order; add one new tenant partition; one repetition per layout.'))
    bundle.write_bytes('PLAN.md', Path('docs/storage-request-checks.md').read_bytes())
    source = source_snapshot(Path.cwd())
    bundle.write('source-manifest.json', source)
    with tarfile.open(root / 'source.tar.gz', 'w:gz') as archive:
        for name in source['files']:
            archive.add(name, arcname=name)
    print(f'Evidence: {root.resolve()}', flush=True)
    trail = session.client('cloudtrail')
    was_logging = trail.get_trail_status(Name=outputs['TrailName'])['IsLogging']
    audit = RequestAudit(session, outputs, args.region, root / 'request_audit')
    cases, windows, summaries, prefix_rows, errors = [], [], [], [], []
    try:
        for layout in ('day_first', 'tenant_first'):
            config = SimpleNamespace(**vars(args), layout=layout, timeout_seconds=600, max_minutes=50,
                repetitions=1, correctness_repetitions=1, graph4_partitions=1, output_dir=root)
            child = EvidenceBundle(root / layout, dict(config=vars(config), source='../source-manifest.json'))
            pilot = AthenaLayoutPilot(session, outputs, child, run_id.replace('-', '_') + '_' + layout, config)
            case = dict(layout=layout, pilot=pilot)
            cases.append(case)
            pilot.require_worker_stopped()
            pilot.trial_buckets = TrialBuckets(session, outputs, args.expected_account, args.region, run_id + '-' + layout, child.root)
            pilot.trial_buckets.provision([dict(id=layout, graph=2, method='athena_msck', x=args.partitions, base=args.partitions, repetition=1)])
        audit.buckets = [case['pilot'].trial_buckets.buckets[case['layout']] for case in cases]
        if not was_logging:
            trail.start_logging(Name=outputs['TrailName'])
        audit.calibrate()
        for case in cases:
            pilot, layout = case['pilot'], case['layout']
            case['fixture'] = prepare(pilot, layout, args.partitions)
            case['ready'] = max(datetime.fromisoformat(pilot.trial_buckets.state['trials'][layout]['metrics_enabled_at']).timestamp() + 900,
                                (int(time.time()) // 60 + 3) * 60)
            print(f'{layout}: {args.partitions} registered partitions and query rows verified', flush=True)
        wait_until(max(case['ready'] for case in cases), 'Metrics activation and quiet setup separation')
        for case in cases:
            pilot, fixture, layout = case['pilot'], case['fixture'], case['layout']
            values = pilot.values(args.partitions)
            pilot.upload(fixture, values, 1000000)
            if pilot.presence(fixture, values) is not False:
                raise AssertionError('The new partition must be absent before MSCK')
            window = dict(id=layout, bucket=fixture['bucket'], started_at=utc())
            windows.append(window)
            try:
                _, record = pilot.query(f'MSCK REPAIR TABLE `{fixture["table"]["Name"]}`', layout + '_msck')
            finally:
                if pilot.last_query_start:
                    window['started_at'] = pilot.last_query_start['started_at']
                window['ended_at'] = utc()
            if pilot.presence(fixture, values) is not True:
                raise AssertionError('MSCK did not register the new partition')
            case['query'] = record
            print(f'{layout}: MSCK succeeded; new partition registered', flush=True)
        wait_until(time.time() + 600, 'Request metric/log delivery; no fixture reads')
        quiet = datetime.now(timezone.utc).replace(second=0, microsecond=0).isoformat()
        for window in windows:
            window['quiet_until'] = quiet
        collector = RequestMetrics(session, args.region, root / 'request_metrics')
        counts = collector.collect(windows)
        audit.collect(windows, wait_seconds=0)
        for case in cases:
            pilot, fixture, layout = case['pilot'], case['fixture'], case['layout']
            details = audit.coverage['windows'][layout]
            listings = [event for event in details['events'] if event['eventName'] in ('ListObjects', 'ListObjectsV2')]
            prefixes = Counter(unquote_plus(event.get('requestParameters', {}).get('prefix', '')) for event in listings)
            for prefix, count in sorted(prefixes.items()):
                prefix_rows.append(dict(layout=layout, prefix=prefix.removeprefix(fixture['root']) or '(table root)', list_requests=count))
            summaries.append(dict(layout=layout, starting_partitions=args.partitions, final_partitions=args.partitions + 1,
                first_level_folders=len({pilot.values(i)[0] for i in range(args.partitions + 1)}),
                **counts[layout], distinct_listed_prefixes=len(prefixes),
                cloudwatch_cloudtrail_agree=counts[layout] == details['observed_counts']))
            pilot.verify(fixture, layout + '_final')
            print(json.dumps(summaries[-1]), flush=True)
        write_csv(root / 'summary.csv', summaries)
        write_csv(root / 'listed_prefixes.csv', prefix_rows)
        if collector.coverage['errors'] or audit.coverage['errors'] or any(not row['cloudwatch_cloudtrail_agree'] for row in summaries):
            raise AssertionError('Request collection needs review; retain the observed results')
    except BaseException as error:
        errors.append(f'{type(error).__name__}: {error}')
        print(errors[-1], flush=True)
    finally:
        for case in reversed(cases):
            pilot = case['pilot']
            try:
                if pilot.trial_buckets:
                    pilot.trial_buckets.cleanup()
            except Exception as error:
                errors.append(f'{case["layout"]} cleanup: {error}')
            pilot.bundle.write('harness-operations.json', pilot.operations)
        if not was_logging:
            try:
                trail.stop_logging(Name=outputs['TrailName'])
            except Exception as error:
                errors.append(f'trail cleanup: {error}')
        bundle.write('request-windows.json', windows)
        bundle.write('results.json', dict(author='Ankit Joshi', completed_at=utc(), summaries=summaries, errors=errors,
            limitations='One repetition per layout. Counts include observed requests, including unsuccessful HEAD probes. AWS delivery is best effort; inspect calibration separately.'))
        bundle.write('artifact-hashes.json', {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest() for path in root.rglob('*') if path.is_file()})
        print(f'{"Complete" if not errors and len(summaries) == 2 else "Needs review"}: {root.resolve()}', flush=True)
    return 0 if not errors and len(summaries) == 2 else 1


if __name__ == '__main__':
    raise SystemExit(main())

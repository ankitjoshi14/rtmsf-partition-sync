"""Historical runner; current experiments use python -m experiments.aws.run.

Run retained AWS fixtures through native notifications and an isolated MSCK ADD baseline.

Example: python -m experiments.aws.legacy_run --stack testfanda-rtmsf-contract-v1
  --expected-account 236680608737 --profile dev-user-user1 --build-manifest build.json
  --mode all --base-partitions 100 --burst-files 5 --output-dir evidence

The stack must already exist with an immutable image and its worker stopped.
Every run creates new tables and object prefixes. The worker is stopped in finally.
No old tables, objects, stack resources, or evidence directories are deleted.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import re
import subprocess
import time
import uuid

from experiments.aws.deploy import validate_target
from experiments.aws.runtime import (
    AwsRuntime, assert_empty_dlq, assert_crash_trace, parquet_payload,
    validate_timing, validate_stack_status,
)
from experiments.evidence import EvidenceBundle, source_snapshot, utc


def fixture_identity(run_id: str) -> dict:
    if not re.fullmatch(r"[a-z][a-z0-9_]{3,70}", run_id):
        raise ValueError("run ID must be a simple unique lowercase identifier")
    return {"root": f"fixture/{run_id}/", "rtmsf": f"rtmsf_{run_id}", "msck": f"msck_{run_id}"}

def canonical_partition(partition: dict) -> dict:
    descriptor = partition["StorageDescriptor"]
    return {"Values": partition["Values"], "StorageDescriptor": {
        "Location": descriptor["Location"],
        "Columns": [{"Name": item["Name"], "Type": item["Type"]} for item in descriptor["Columns"]],
        "InputFormat": descriptor["InputFormat"],
        "OutputFormat": descriptor["OutputFormat"],
        "SerdeInfo": {"SerializationLibrary": descriptor["SerdeInfo"]["SerializationLibrary"], "Parameters": descriptor["SerdeInfo"].get("Parameters", {})},
    }}

def assert_catalog(actual: list[dict], expected: list[dict]) -> None:
    def normalized(parts):
        return sorted((canonical_partition(item) for item in parts), key=lambda item: tuple(item["Values"]))
    if normalized(actual) != normalized(expected):
        raise AssertionError("catalog differs in exact values, location, schema, SerDe, or partition membership")

def assert_rows(actual: list[list[str]], expected: list[list[str]]) -> None:
    if sorted(actual) != sorted(expected):
        raise AssertionError(f"query rows differ: expected {len(expected)}, observed {len(actual)}")


class SmallRun(AwsRuntime):
    """Historical workload interface retained for earlier reproduction commands."""

    def __init__(self, session, outputs, bundle, run_id, timeout):
        super().__init__(session, outputs, bundle, run_id, timeout)
        self.identity = fixture_identity(run_id)
        self.tables, self.expected, self.rows = {}, {"rtmsf": [], "msck": []}, {"rtmsf": [], "msck": []}

    def create_fixtures(self) -> None:
        self.require_worker_stopped()
        glue = self.clients["glue"]
        database = self.outputs["GlueDatabaseName"]
        for method, prototype, bucket_key in (("rtmsf", "RtmsfTableName", "DataBucketName"), ("msck", "MsckTableName", "MsckBucketName")):
            template = glue.get_table(DatabaseName=database, Name=self.outputs[prototype])["Table"]
            table = {key: deepcopy(template[key]) for key in ("TableType", "Parameters", "PartitionKeys", "StorageDescriptor")}
            table["Name"] = self.identity[method]
            table["StorageDescriptor"]["Location"] = f"s3://{self.outputs[bucket_key]}/{self.identity['root']}"
            glue.create_table(DatabaseName=database, TableInput=table)
            self.tables[method] = table
        self.bundle.write("fixtures.json", self.tables)

    def configure_worker(self, *, crash: bool = False) -> None:
        ecs = self.clients["ecs"]
        service = self.service()
        self.require_worker_stopped()
        original = ecs.describe_task_definition(taskDefinition=service["taskDefinition"])["taskDefinition"]
        fields = ("family", "taskRoleArn", "executionRoleArn", "networkMode", "containerDefinitions", "volumes", "placementConstraints", "requiresCompatibilities", "cpu", "memory", "runtimePlatform", "ephemeralStorage")
        task = {key: deepcopy(original[key]) for key in fields if key in original}
        container = next(item for item in task["containerDefinitions"] if item["name"] == "worker")
        if "@sha256:" not in container["image"] or not container["image"].startswith(self.outputs["EcrRepositoryUri"] + "@sha256:"):
            raise ValueError("worker image must be an immutable digest from this stack's repository")
        env = {item["name"]: item["value"] for item in container.get("environment", [])}
        validate_timing(env)
        env["RTMSF_TABLE_IDS"] = json.dumps([f"{self.outputs['GlueDatabaseName']}.{self.identity['rtmsf']}"])
        for key in ("RTMSF_EXPERIMENT_CRASH_MARKER_SOURCE_ID", "RTMSF_EXPERIMENT_CRASH_MARKER_KEY", "RTMSF_EXPERIMENT_FAULT"):
            env.pop(key, None)
        container["entryPoint"] = ["python", "-m", "experiments.aws.crash_worker" if crash else "rtmsf.aws_app"]
        container.pop("command", None)
        if crash:
            env["RTMSF_EXPERIMENT_FAULT"] = json.dumps({
                "operation": "ADD", "point": "before_processing",
                "partition_path": "dt=2026-09-10/site=replay/hour=0000",
                "source_id": "fixture",
                "table_id": f"{self.outputs['GlueDatabaseName']}.{self.identity['rtmsf']}",
                "marker_bucket": self.outputs["DataBucketName"],
                "marker_key": f"_experiment/crash/{self.run_id}.json",
            })
        container["environment"] = [{"name": key, "value": value} for key, value in sorted(env.items())]
        registered = ecs.register_task_definition(**task)["taskDefinition"]
        self.task_definition = registered["taskDefinitionArn"]
        ecs.update_service(cluster=self.outputs["ClusterName"], service=self.outputs["ServiceName"], taskDefinition=self.task_definition, desiredCount=0)
        self.bundle.write(f"task-definition{'-crash' if crash else ''}.json", registered)
        self.wait_worker(False, configured=True)

    def snapshot(self, method: str) -> list[dict]:
        result, token = [], None
        for _ in range(100):
            request = {"DatabaseName": self.outputs["GlueDatabaseName"], "TableName": self.identity[method], "MaxResults": 1000}
            if token:
                request["NextToken"] = token
            page = self.clients["glue"].get_partitions(**request)
            result.extend(page.get("Partitions", []))
            token = page.get("NextToken")
            if not token:
                return result
        raise RuntimeError("bounded Glue partition pagination exhausted")

    def wait_catalog(self, method: str, label: str) -> dict:
        deadline = time.monotonic() + self.timeout
        observations = []
        while time.monotonic() < deadline:
            before = utc()
            actual = self.snapshot(method)
            after = utc()
            observed_mono = time.monotonic()
            observations.append({"started_at": before, "completed_at": after, "count": len(actual)})
            try:
                assert_catalog(actual, self.expected[method])
            except AssertionError:
                time.sleep(1)
                continue
            record = {"expected": self.expected[method], "actual": actual, "observations": observations, "observed_at": after, "observer_monotonic_seconds": observed_mono}
            self.bundle.write(f"snapshots/{label}.json", record)
            return record
        self.bundle.write(f"snapshots/{label}-timeout.json", {"expected": self.expected[method], "actual": actual, "observations": observations})
        raise TimeoutError(f"exact catalog state not observed for {label} within {self.timeout}s")

    def partition(self, method: str, values: tuple[str, str, str]) -> dict:
        descriptor = deepcopy(self.tables[method]["StorageDescriptor"])
        path = self.partition_path(values)
        # Native MSCK records the directory URI without a trailing slash.
        descriptor["Location"] += path if method == "rtmsf" else path.removesuffix("/")
        return {"Values": list(values), "StorageDescriptor": descriptor}

    @staticmethod
    def partition_path(values: tuple[str, str, str]) -> str:
        return "/".join(f"{name}={value}" for name, value in zip(("dt", "site", "hour"), values)) + "/"

    def put(self, method: str, values: tuple[str, str, str], record_id: int, payload: bytes | None = None) -> str:
        payload = parquet_payload(record_id) if payload is None else payload
        bucket = self.outputs["DataBucketName" if method == "rtmsf" else "MsckBucketName"]
        key = f"{self.identity['root']}{self.partition_path(values)}part-{record_id:06d}.parquet"
        started = utc()
        response = self.clients["s3"].put_object(Bucket=bucket, Key=key, Body=payload, IfNoneMatch="*", ContentType="application/octet-stream")
        self.inputs.append({"method": method, "bucket": bucket, "key": key, "sha256": hashlib.sha256(payload).hexdigest(), "bytes": len(payload), "record_id": record_id, "values": values, "upload_started_at": started, "upload_completed_at": utc(), "etag": response.get("ETag")})
        self.rows[method].append([str(record_id), str(record_id * 10), *values])
        return key

    def delete(self, key: str, record_id: int) -> None:
        if not key.startswith(self.identity["root"]) or key not in {item["key"] for item in self.inputs if item["method"] == "rtmsf"}:
            raise ValueError("refusing delete outside objects created by this run")
        self.clients["s3"].delete_object(Bucket=self.outputs["DataBucketName"], Key=key)
        self.rows["rtmsf"] = [row for row in self.rows["rtmsf"] if row[0] != str(record_id)]

    def seed(self, count: int) -> None:
        for index in range(count):
            values = ("2026-09-10", "baseline", f"{index:04d}")
            payload = parquet_payload(index)
            for method in ("rtmsf", "msck"):
                self.put(method, values, index, payload)
                self.expected[method].append(self.partition(method, values))
        for method in ("rtmsf", "msck"):
            for offset in range(0, count, 100):
                response = self.clients["glue"].batch_create_partition(DatabaseName=self.outputs["GlueDatabaseName"], TableName=self.identity[method], PartitionInputList=self.expected[method][offset:offset + 100])
                if response.get("Errors"):
                    raise RuntimeError(f"fixture partition registration failed: {response['Errors']}")
            self.wait_catalog(method, f"{method}-baseline")
            self.verify_query(method, f"{method}-baseline")

    def verify_query(self, method: str, label: str) -> None:
        rows, _ = self.query(f'SELECT record_id, amount, dt, site, hour FROM "{self.identity[method]}" ORDER BY record_id', label)
        actual = rows[1:] if rows else []
        self.bundle.write(f"assertions/{label}.json", {"expected_rows": self.rows[method], "actual_rows": actual, "passed": sorted(actual) == sorted(self.rows[method]), "measurement": "post-catalog query correctness, not query-visibility latency"})
        assert_rows(actual, self.rows[method])

    def compare(self, base_count: int, burst_files: int = 1) -> list[dict]:
        values = ("2026-09-10", "new", "0000")
        records = []
        payloads = [(base_count + offset, parquet_payload(base_count + offset)) for offset in range(burst_files)]
        for method in ("rtmsf", "msck"):
            self.set_phase(f"maintenance-{method}")
            started, clock = utc(), time.monotonic()
            for record_id, payload in payloads:
                self.put(method, values, record_id, payload)
            upload_seconds = time.monotonic() - clock
            self.expected[method].append(self.partition(method, values))
            method_seconds = None
            query_id = None
            if method == "msck":
                _, query_record = self.query(f"MSCK REPAIR TABLE `{self.identity['msck']}`", "msck-repair")
                method_seconds = query_record["elapsed_seconds"]
                query_id = query_record["query_id"]
            observation = self.wait_catalog(method, f"{method}-comparison-final")
            visibility = observation["observer_monotonic_seconds"] - clock
            self.set_phase(f"verify-{method}")
            self.verify_query(method, f"{method}-comparison-final")
            records.append({"method": method, "method_order": len(records) + 1, "baseline_partitions": base_count, "new_partitions": 1, "new_files": burst_files, "upload_started_at": started, "upload_seconds": upload_seconds, "catalog_observed_at": observation["observed_at"], "catalog_visibility_seconds": visibility, "method_seconds": method_seconds, "msck_query_id": query_id, "observer_poll_seconds": 1, "exact_catalog_passed": True, "exact_query_rows_passed": True})
            if method == "rtmsf":
                self.drain("after-rtmsf-comparison")
        first = [(item["key"].split(self.identity["root"], 1)[1], item["sha256"]) for item in self.inputs if item["method"] == "rtmsf"]
        second = [(item["key"].split(self.identity["root"], 1)[1], item["sha256"]) for item in self.inputs if item["method"] == "msck"]
        if first != second:
            raise AssertionError("comparison inputs are not byte matched")
        return records

    def correctness(self, start_id: int, burst_files: int) -> list[dict]:
        records = []
        values = ("2026-09-10", "correctness", "0000")
        keys = []

        def check(label):
            self.set_phase(f"correctness-{label}-observe")
            self.wait_catalog("rtmsf", label)
            self.verify_query("rtmsf", label)
            self.drain(label)
            records.append({"scenario": label, "rows": len(self.rows["rtmsf"]), "catalog_passed": True, "query_passed": True, "native_notifications": True})
            print(f"{label}: exact catalog and {len(self.rows['rtmsf'])} query rows verified", flush=True)

        self.set_phase("correctness-add")
        keys.append((self.put("rtmsf", values, start_id), start_id))
        self.expected["rtmsf"].append(self.partition("rtmsf", values))
        check("ordinary-add")
        self.set_phase("correctness-append")
        for offset in range(1, burst_files + 1):
            record_id = start_id + offset
            keys.append((self.put("rtmsf", values, record_id), record_id))
        check("same-partition-append")
        self.set_phase("correctness-partial-delete")
        self.delete(*keys.pop(0))
        check("partial-delete")
        self.set_phase("correctness-final-delete")
        for key, record_id in keys:
            self.delete(key, record_id)
        self.expected["rtmsf"] = [item for item in self.expected["rtmsf"] if item["Values"] != list(values)]
        check("final-delete")
        return records

    def crash_replay(self, record_id: int) -> dict:
        self.set_phase("crash-replay-setup")
        self.stop_worker()
        self.configure_worker(crash=True)
        started = datetime.now(timezone.utc)
        values = ("2026-09-10", "replay", "0000")
        self.put("rtmsf", values, record_id)
        self.expected["rtmsf"].append(self.partition("rtmsf", values))
        self.set_phase("crash-replay")
        self.start_worker()
        self.wait_catalog("rtmsf", "crash-replay")
        self.verify_query("rtmsf", "crash-replay")
        self.drain("crash-replay")
        ecs = self.clients["ecs"]
        stopped_ids = ecs.list_tasks(cluster=self.outputs["ClusterName"], serviceName=self.outputs["ServiceName"], desiredStatus="STOPPED", maxResults=100)["taskArns"]
        stopped = ecs.describe_tasks(cluster=self.outputs["ClusterName"], tasks=stopped_ids)["tasks"] if stopped_ids else []
        stopped = [task for task in stopped if task["createdAt"] >= started]
        active_ids = ecs.list_tasks(cluster=self.outputs["ClusterName"], serviceName=self.outputs["ServiceName"], desiredStatus="RUNNING")["taskArns"]
        active = ecs.describe_tasks(cluster=self.outputs["ClusterName"], tasks=active_ids)["tasks"] if active_ids else []
        trace = {"started_at": started, "stopped_tasks": stopped, "running_tasks": active, "marker_bucket": self.outputs["DataBucketName"], "marker_key": f"_experiment/crash/{self.run_id}.json", "fault": "experiment launcher exit86 after durable marker, immediately before selected ADD PMCP processing"}
        self.bundle.write("crash-replay-trace.json", trace)
        assert_crash_trace(stopped, active)
        return {"scenario": "process-crash-and-durable-replay", "rows": len(self.rows["rtmsf"]), "catalog_passed": True, "query_passed": True, "nonoverlap_passed": True, "native_notifications": True}

    def collect(self) -> None:
        self.set_phase("evidence-collection")
        self.bundle.write("input-manifest.json", self.inputs)
        self.bundle.write("phase-boundaries.json", self.phases)
        self.bundle.write("worker-lifecycle.json", self.lifecycle)
        try:
            self.collect_runtime()
        finally:
            self.bundle.write("harness-api-operations.json", self.operations)


def main() -> None:
    import boto3
    from botocore.config import Config

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stack", required=True)
    parser.add_argument("--expected-account", required=True)
    parser.add_argument("--profile", required=True)
    parser.add_argument("--region", default="us-west-2")
    parser.add_argument("--build-manifest", type=Path, required=True)
    parser.add_argument("--mode", choices=("correctness", "compare", "all"), default="all")
    parser.add_argument("--base-partitions", type=int, default=100)
    parser.add_argument("--burst-files", type=int, default=5, help="same-partition append files in correctness case")
    parser.add_argument("--change-files", type=int, default=1, help="native files in the one new comparison partition; use100 for burst study")
    parser.add_argument("--crash-replay", action="store_true", help="exercise selected ADD crash/replay using an experiment-target image")
    parser.add_argument("--timeout-seconds", type=int, default=240)
    parser.add_argument("--output-dir", type=Path, default=Path("evidence/runs"))
    args = parser.parse_args()
    if not 0 <= args.base_partitions <= 1000 or not 1 <= args.burst_files <= 100 or not 1 <= args.change_files <= 100 or not 30 <= args.timeout_seconds <= 600:
        parser.error("bounded run requires base0..1000, files1..100 and timeout30..600")
    root = Path.cwd()
    snapshot = source_snapshot(root)
    build = json.loads(args.build_manifest.read_text())
    if build.get("source_hash") != snapshot["sha256"]:
        raise ValueError("current source differs from the explicit image build manifest")
    session = boto3.Session(profile_name=args.profile, region_name=args.region)
    config = Config(connect_timeout=3, read_timeout=15, retries={"total_max_attempts": 1})
    account = session.client("sts", config=config).get_caller_identity()["Account"]
    validate_target(account, args.expected_account, args.stack, args.region)
    stack = session.client("cloudformation", config=config).describe_stacks(StackName=args.stack)["Stacks"][0]
    validate_stack_status(stack["StackStatus"])
    outputs = {item["OutputKey"]: item["OutputValue"] for item in stack["Outputs"]}
    run_id = "run_" + datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_") + uuid.uuid4().hex[:8]
    manifest = {"run_id": run_id, "created_at": utc(), "account": account, "region": args.region, "stack": args.stack, "stack_id": stack["StackId"], "outputs": outputs, "mode": args.mode, "base_partitions": args.base_partitions, "burst_files": args.burst_files, "change_files": args.change_files, "source": snapshot, "build": build, "git_head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip(), "git_status": subprocess.check_output(["git", "status", "--porcelain"], cwd=root, text=True), "python": platform.python_version(), "dependencies": {name: importlib.metadata.version(name) for name in ("boto3", "botocore", "pyarrow")}, "method_order": ["rtmsf", "msck"], "timing": {"SETTLING_MS": 10000, "MAXIMUM_MS": 31000, "QUEUE_VISIBILITY_SECONDS": 180, "observer_poll_seconds": 1, "harness_timeout_seconds": args.timeout_seconds}, "coverage": {"native_events": True, "worker_request_attempts": "app telemetry", "msck_internal_requests": None, "query_checks": "post-catalog exact data checks", "worker_count": 1}}
    bundle = EvidenceBundle(args.output_dir / run_id, manifest)
    for relative in snapshot["files"]:
        bundle.write_bytes(f"source/{relative}", (root / relative).read_bytes())
    run = SmallRun(session, outputs, bundle, run_id, args.timeout_seconds)
    summary = {"run_id": run_id, "status": "failed", "comparisons": [], "correctness": []}
    failure = None
    lifecycle_owned = False
    try:
        run.require_worker_stopped()
        run.create_fixtures()
        run.seed(args.base_partitions)
        run.configure_worker()
        registered = json.loads((bundle.root / "task-definition.json").read_text())
        image = next(item["image"] for item in registered["containerDefinitions"] if item["name"] == "worker")
        if build.get("image") != image:
            raise ValueError("deployed task image differs from build manifest")
        lifecycle_owned = True
        run.start_worker()
        runtime = run.lifecycle[-1]["tasks"][0]
        actual_digest = next(item.get("imageDigest") for item in runtime["containers"] if item["name"] == "worker")
        if actual_digest != image.rsplit("@", 1)[1]:
            raise ValueError("running image digest does not match the built image")
        run.set_phase("startup-drain")
        run.drain("startup")
        if args.mode in {"compare", "all"}:
            summary["comparisons"] = run.compare(args.base_partitions, args.change_files)
        if args.mode in {"correctness", "all"}:
            summary["correctness"] = run.correctness(args.base_partitions + args.change_files + 1000, args.burst_files)
        if args.crash_replay:
            summary["correctness"].append(run.crash_replay(args.base_partitions + args.change_files + 2000))
        summary["status"] = "passed"
    except KeyboardInterrupt as error:
        failure = error
        summary["error"] = "KeyboardInterrupt: run interrupted"
        summary["interrupted"] = True
    except Exception as error:
        failure = error
        summary["error"] = f"{type(error).__name__}: {error}"
    finally:
        if lifecycle_owned:
            try:
                run.set_phase("worker-shutdown")
                run.stop_worker()
                summary["worker_stopped"] = True
            except Exception as error:
                summary["worker_stopped"] = False
                summary["shutdown_error"] = str(error)
                summary["status"] = "failed"
                failure = failure or error
        try:
            run.collect()
            for record in summary["comparisons"]:
                if record["method"] == "rtmsf":
                    counts = run.request_counts.get("rtmsf_comparison")
                    if counts is not None:
                        record["storage_request_attempts"] = sum(value for key, value in counts.items() if key.startswith("S3."))
                        record["catalog_request_attempts"] = sum(value for key, value in counts.items() if key.startswith("Glue."))
                        record["queue_request_attempts"] = sum(value for key, value in counts.items() if key.startswith("SQS."))
                    record["request_observation_window"] = "change upload through catalog check, subsequent query correctness check and eight-second observed queue drain; ends before MSCK upload"
        except Exception as error:
            summary["collection_error"] = str(error)
            summary["status"] = "failed"
            failure = failure or error
        bundle.seal(summary)
        print(str(bundle.root.resolve()), flush=True)
    if failure:
        raise failure


if __name__ == "__main__":
    main()

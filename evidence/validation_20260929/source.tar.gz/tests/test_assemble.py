import csv
import hashlib
import json

import pytest

from experiments.evidence import EvidenceBundle
from experiments.figures import COLUMNS, graph_row


def batch(path, x=100, *, source='source', image='repo@sha256:digest', status='passed'):
    config = dict(region='us-west-2', expected_account='123456789012', stack='rtmsf-test',
                  request_source='cloudwatch', timeout_seconds=600, audit_wait_seconds=600, repetitions=1,
                  correctness_repetitions=1, graph4_partitions=100)
    bundle = EvidenceBundle(path, dict(source={'sha256': source}, config=config))
    bundle.write('image-build.json', {'image': image})
    bundle.write_bytes('source.tar.gz', b'retained source')
    bundle.write('report_inputs.json', dict(recovery_results=[], checks=[], metadata={
        'config': config, 'graphs': [3], 'run_status': status, 'data_kind': 'aws_pilot',
        'graph_results': [dict(graph=3, method='rtmsf', x_value=x, repetition=1,
                               trial_id=f'g2_rtmsf_{x}_r1', status=status)],
    }))
    with (path / 'graph_data.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=COLUMNS)
        writer.writeheader()
        writer.writerow(graph_row(3, 'rtmsf', 'visibility_delay_s', x,
                                  None if status != 'passed' else 12))
    seal(path)
    return path


def seal(path):
    hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
              for p in path.iterdir() if p.is_file() and p.name != 'artifact-hashes.json'}
    (path / 'artifact-hashes.json').write_text(json.dumps(hashes))


def test_assembly_keeps_failures_unknowns_and_portable_provenance(tmp_path):
    from experiments.assemble import assemble

    a, b = batch(tmp_path / 'a'), batch(tmp_path / 'b', 1000, status='incomplete')
    original = (a / 'graph_data.csv').read_bytes()
    output = tmp_path / 'combined'
    assemble([a, b], output)
    with (output / 'graph_data.csv').open() as stream:
        rows = list(csv.DictReader(stream))
    assert [(r['x_value'], r['y_value']) for r in rows] == [('100', '12'), ('1000', '')]
    inputs = json.loads((output / 'report_inputs.json').read_text())
    assert inputs['metadata']['run_status'] == 'incomplete_or_failed'
    assert [r['batch'] for r in inputs['metadata']['graph_results']] == ['a', 'b']
    assert (output / 'batches/a/graph_data.csv').read_bytes() == original
    assert (a / 'graph_data.csv').read_bytes() == original
    assert 'batches/b/SUMMARY.md' not in (output / 'SUMMARY.md').read_text()
    assert (output / 'graph_3.png').exists()
    for name, digest in json.loads((output / 'artifact-hashes.json').read_text()).items():
        assert hashlib.sha256((output / name).read_bytes()).hexdigest() == digest


@pytest.mark.parametrize('change', ['overlap', 'source', 'image', 'corrupt', 'config', 'collection_wait'])
def test_assembly_rejects_incompatible_or_damaged_batches_before_writing(tmp_path, change):
    from experiments.assemble import assemble

    a = batch(tmp_path / 'a')
    b = batch(tmp_path / 'b', 100 if change == 'overlap' else 1000,
              source='other' if change == 'source' else 'source',
              image='other@sha256:digest' if change == 'image' else 'repo@sha256:digest')
    if change == 'corrupt':
        (b / 'graph_data.csv').write_text('damaged')
    if change in ('config', 'collection_wait'):
        manifest = json.loads((b / 'manifest.json').read_text())
        if change == 'config':
            manifest['config']['request_source'] = 'cloudtrail'
        else:
            manifest['config']['audit_wait_seconds'] = 1200
        (b / 'manifest.json').write_text(json.dumps(manifest))
        seal(b)
    with pytest.raises(ValueError):
        assemble([a, b], tmp_path / 'combined')
    assert not (tmp_path / 'combined').exists()


def test_correctness_selection_excludes_comparisons_but_retains_original_run(tmp_path):
    from experiments.assemble import assemble

    comparison = batch(tmp_path / 'comparison')
    correctness = batch(tmp_path / 'correctness')
    inputs = json.loads((correctness / 'report_inputs.json').read_text())
    inputs['metadata']['graphs'] = [1, 3]
    inputs['metadata']['graph_results'].append(dict(graph=1, method='rtmsf', repetition=1,
                                                   trial_id='lifecycle_r1', status='passed'))
    inputs['checks'] = [dict(name='short_burst', repetition=1, status='passed')]
    (correctness / 'report_inputs.json').write_text(json.dumps(inputs))
    with (correctness / 'graph_data.csv').open('a', newline='') as stream:
        csv.DictWriter(stream, fieldnames=COLUMNS).writerow(
            graph_row(1, 'rtmsf', 'observed_partition_presence', 0, 0))
    seal(correctness)
    output = tmp_path / 'combined'
    assemble([comparison], output, correctness_run=correctness)
    result = json.loads((output / 'report_inputs.json').read_text())
    assert result['metadata']['graphs'] == [1, 3]
    assert len(result['metadata']['graph_results']) == 2
    assert result['checks'][0]['batch'] == 'correctness'
    assert len(list(csv.DictReader((output / 'graph_data.csv').open()))) == 2
    assert (output / 'batches/correctness/graph_data.csv').read_bytes() == (correctness / 'graph_data.csv').read_bytes()

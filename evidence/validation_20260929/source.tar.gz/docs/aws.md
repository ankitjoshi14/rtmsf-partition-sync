# Run the AWS experiments

This runbook covers the five-graph AWS experiments in
[the experiment specification](experiments.md). Its runner and reports are
implemented; accepted AWS results must come from the retained run evidence.

Run these commands from the repository root. Use your own AWS profile, account,
VPC and public subnets. The fixture tools are bounded to `us-west-2` and
`rtmsf-` stack names. The profile needs permission to provision the resources
in `src/experiments/aws/template.yaml` and operate the experiment.

The stack starts with zero workers. It creates disposable table fixtures and
fresh S3/SQS/Glue/Athena/ECR/ECS resources. The worker itself only maintains
configured existing tables. Public subnet egress on HTTPS lets Fargate reach AWS
APIs without creating a NAT gateway.

## 1. Install and provision

Replace the example account/network values before running:

```bash
uv sync --frozen --extra dev
export RTMSF_PROFILE=your-profile
export RTMSF_ACCOUNT=123456789012
export RTMSF_REGION=us-west-2
export RTMSF_STACK=rtmsf-paper-v1

uv run --frozen --extra dev python -m experiments.aws.deploy \
  --stack "$RTMSF_STACK" --expected-account "$RTMSF_ACCOUNT" \
  --profile "$RTMSF_PROFILE" --region "$RTMSF_REGION" \
  --experiment-id paper-v1 --database rtmsf_experiments \
  --vpc vpc-REPLACE --subnets subnet-REPLACE subnet-REPLACE
```

Deploy the stack once, then reuse it for sequential experiment executions.
Choose new stack, experiment and database names if creating a separate deployment.
`--experiment-id` is 3–20 lowercase letters/digits/hyphens, starting with a letter.
The named base buckets become `rtmsf-paper-v1-data-<account>-<region>` and
`rtmsf-paper-v1-crawler-<account>-<region>`; other stack resources inherit the
`rtmsf-paper-v1` stack prefix. These names apply to new deployments; existing AWS
resources retain their original names.
The command prints the stack outputs. Store its `EcrRepositoryUri` in
`RTMSF_ECR`; it is a registry/repository address, not a credential.

## 2. Build this source and record its identity

Use Docker with ARM64 build support. Rebuild the worker image when its runtime
code or dependency configuration changes. Host-only runner, report, test, or
documentation changes may reuse an image whose runtime file hashes still match;
each execution separately archives and identifies its current host source.
The default Docker target is `production`, whose entry point is `rtmsf.aws_app`.
Build `--target experiment` for this pilot so the same image also contains
`experiments.aws.crash_worker`. The runner selects normal startup for measurement
trials and the experiment launcher only for deliberate fault trials.

For a crash case, the runner passes the target table, partition, ADD/DROP and
crash point as configuration. At that exact point, the launcher creates a
crash-once marker in S3 and exits abruptly. ECS starts a replacement with the
**same image and configuration**. The durable marker prevents a second injected
crash; the replacement processes the unacknowledged SQS message when it becomes
available again. The runner stays outside the worker and verifies the crash,
message replay/acknowledgement, and catalog state. Each case/repetition gets a
fresh marker. See [the four crash cases](experiments.md#table-1--crash-recovery).

```bash
export RTMSF_ECR=REPLACE_WITH_EcrRepositoryUri
export RTMSF_SOURCE_HASH=$(uv run --frozen --extra dev python -c \
  'from pathlib import Path; from experiments.evidence import source_snapshot; print(source_snapshot(Path("."))["sha256"])')
export RTMSF_TAG=pilot-source-$RTMSF_SOURCE_HASH
export RTMSF_BUILD_MANIFEST="runs/build-$RTMSF_SOURCE_HASH/image-build.json"

docker buildx build --platform linux/arm64 --provenance=false --load \
  --target experiment -t rtmsf:pilot .
aws ecr get-login-password --profile "$RTMSF_PROFILE" --region "$RTMSF_REGION" \
  | docker login --username AWS --password-stdin "${RTMSF_ECR%%/*}"
docker tag rtmsf:pilot "$RTMSF_ECR:$RTMSF_TAG"
docker push "$RTMSF_ECR:$RTMSF_TAG"

export RTMSF_DIGEST=$(aws ecr describe-images \
  --profile "$RTMSF_PROFILE" --region "$RTMSF_REGION" \
  --repository-name "${RTMSF_ECR#*/}" --image-ids imageTag="$RTMSF_TAG" \
  --query 'imageDetails[0].imageDigest' --output text)
export RTMSF_IMAGE="$RTMSF_ECR@$RTMSF_DIGEST"

uv run --frozen --extra dev python - <<'PY'
import json, os, subprocess
from pathlib import Path
inspect_image = '''
import hashlib, importlib.metadata, json
from pathlib import Path
root = Path('/app')
files = sorted((root / 'src/rtmsf').rglob('*.py')) + [
    root / name for name in ('src/experiments/__init__.py',
                            'src/experiments/aws/__init__.py',
                            'src/experiments/aws/crash_worker.py')]
print(json.dumps({
    'files': {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
    'runtime_dependencies': {n: importlib.metadata.version(n) for n in ('boto3', 'botocore')},
}))
'''
runtime = subprocess.check_output([
    'docker', 'run', '--rm', '--entrypoint', 'python', 'rtmsf:pilot', '-c',
    inspect_image,
], text=True)
manifest = Path(os.environ['RTMSF_BUILD_MANIFEST'])
manifest.parent.mkdir(parents=True, exist_ok=True)
manifest.write_text(json.dumps({
    'source_hash': os.environ['RTMSF_SOURCE_HASH'],
    'image': os.environ['RTMSF_IMAGE'],
    'target': 'experiment',
    **json.loads(runtime),
}, indent=2) + '\n')
PY
```

The immutable image digest identifies the runtime, including dependencies selected
by the Docker build. `uv.lock` pins the local test/harness environment. No AWS
credentials are baked into the image or build manifest.

## 3. Deploy and run a small validation

```bash
uv run --frozen --extra dev python -m experiments.aws.deploy \
  --stack "$RTMSF_STACK" --expected-account "$RTMSF_ACCOUNT" \
  --profile "$RTMSF_PROFILE" --region "$RTMSF_REGION" \
  --update-image --image "$RTMSF_IMAGE"

uv run --frozen --extra experiment python -m experiments.aws.run \
  --stack "$RTMSF_STACK" --expected-account "$RTMSF_ACCOUNT" \
  --profile "$RTMSF_PROFILE" --region "$RTMSF_REGION" \
  --sizes 100 1000 --files 1 10 100 1000 --graph4-partitions 1000 \
  --layout-sizes 100 --repetitions 1 --timeout-seconds 600 --max-minutes 180 \
  --request-source cloudwatch --audit-wait-seconds 600 \
  --build-manifest "$RTMSF_BUILD_MANIFEST" --output-dir runs
```

This validation selects all five graphs, fresh fixtures, Q=10 seconds, and one
repetition per condition. A smaller Graph 5-only check uses
`--graph5-only --layout-sizes 100 --repetitions 1 --max-minutes 60`
with the same account, stack, image-manifest and collection options: four trials.
Each measured trial gets its own bucket, for example
`rtmsf-g2-glue-p1000-r1-<run>` or `rtmsf-g4-rtmsf-p1000-f100-r1-<run>`.
Wait 15 minutes after enabling CloudWatch, then calibrate CloudTrail calls; the final collection waits 10 minutes
with these buckets idle. Two complete quiet minutes separate setup reads from
each measurement: AWS assigned some setup reads to the second following minute
in the September 23 run. This guard addresses that observation, not a guaranteed
AWS delivery bound. Final verification queries run afterward. The runner removes
the new buckets and restores its temporary queue permissions and CloudTrail
selectors. `trial-buckets.json` records resource ownership and cleanup.
Each crawler trial also gets a separate queue, removed during cleanup, so late
notifications from another trial cannot interfere.
Graph 5 requires isolated CloudWatch buckets. `--request-source cloudtrail`
remains available only for selective earlier-graph modes, for historical checks.
After interruption, stop this run's worker/crawler and rerun the command with
`--cleanup-run <printed-run-directory>` to finish bucket/table cleanup and
restore permissions. This writes a separate receipt and preserves original evidence.
It targets the lifecycle trace, RTMSF/crawler/MSCK partition-size comparisons,
RTMSF/crawler file-count comparisons, RTMSF/Athena key-order comparisons,
and four ADD/DROP crash boundaries.
It also runs the seven supporting burst, routing, replay, rapid-change, and
retry checks. Any check that does not run stays explicitly **not attempted**.
Use `--repetitions 5 --correctness-repetitions 3` for the planned repeat run:
five per comparison condition, three per lifecycle/crash/supporting case.
Without the second option, both counts use `--repetitions` (default 1).
Choose the time budget explicitly. `--max-minutes` stops new trials from
starting; setup, active operations, shutdown and final collection can extend
elapsed time beyond it. Supported inputs are up to 100K main-layout partitions,
10K existing files and 10K Graph 5 partitions. Those limits do not establish
successful scale measurements. Use separate batches for the paper matrix below.

Read the printed directory's `SUMMARY.md`, `graph_data.csv`, `graph_1`–`graph_5`
PNG/PDF files, `recovery_table.md`, and `checks_table.md`. Failed, incomplete,
and unattempted conditions remain visible; an unstarted condition is not an
attempt. Retain `manifest.json`, `experiment.jsonl`, query/runtime evidence,
request windows and raw audit records, `report_inputs.json`, and
`artifact-hashes.json`. The build manifest verifies local runtime files against
the image contents and checks the deployed digest; the pilot retains it as
`image-build.json` and records actual task definitions.
The exact source used by an execution is retained in `source.tar.gz`.
The source archive includes the current experiment specification and tests.
Selected, verified exports belong in `evidence/`; the
runner does not publish or curate them automatically.
CSV times are rounded to three decimals; full timestamps remain in the experiment log.
Raw runs default to `runs/`, which is ignored by Git. One execution produces:

```text
runs/<execution>/
├── SUMMARY.md             # Start here: outcomes and missing measurements
├── graph_data.csv         # Points used for every graph
├── graph_1.png / .pdf      # Likewise graph_2 through graph_5
├── recovery_table.md      # Four crash cases
├── checks_table.md        # Supporting workloads
├── report_inputs.json     # Recreate the tables and captions offline
└── ...                    # Configuration, logs, raw observations, source and hashes
```

The command returns exit code 0 only when all selected work and required evidence
collection succeed; failed, incomplete or unattempted work returns 1 after saving
the bundle. `SUMMARY.md` and `report_inputs.json` record that status and errors.
The graph CSV has 12 columns, including `layout` after `method`, with separate
HEAD, GET and LIST rows. Graphs 2/4/5 sum these within each complete repetition
and layout. Graph 5 uses two panels with shared axes and the same method colors.
Legacy 11-column CSVs remain readable. Bucket names never determine the figures.
`--update-image` keeps the deployed CloudFormation template and its resource
names, changing only the worker image parameter. Template changes need a fresh
deployment through this utility. Rebuild after runtime source/dependency changes. A historical manifest without
`files`, or one with mismatched runtime hashes, cannot validate this checkout.
Keep each verified manifest with its evidence instead of overwriting old records.

### What a run and a rerun create

Every execution gets an ID such as `run_20260929_090000_a1b2`: UTC date/time plus
a random suffix. All its repetitions and graphs go into **one local folder**,
`runs/run_20260929_090000_a1b2/`. The folder is created automatically and contains
the files shown above. The runner records actual resource names in
`experiment.jsonl`; `trial-buckets.json` also maps measurement tables/buckets
and records their cleanup.
`runtime-api-counts.json` contains run-wide adapter totals for diagnostics;
graph request counts come from the separate per-trial measurement windows.

The stack and Glue database (`rtmsf_experiments` by default) are reused.
**Tables are fresh for every condition,
method and repetition.** For Graphs 2/3 at 100 partitions, repetition 1:

| Method | Example table in `rtmsf_experiments` |
|---|---|
| RTMSF | `rtmsf_scale_p100_r1_20260929_090000_a1b2` |
| Glue event crawler | `crawler_scale_p100_r1_20260929_090000_a1b2` |
| Athena MSCK | `msck_scale_p100_r1_20260929_090000_a1b2` |

Names follow **method → experiment → condition → repetition → run**.
`p100` means 100 starting partitions, `f100` means 100 existing files in the
changed partition, and `r1` means repetition 1. Graphs 2 and 3 share the `scale`
tables and trials. Other RTMSF table examples use the same run suffix:

| Purpose | Table name (`<run>` = `20260929_090000_a1b2`) |
|---|---|
| Graph 1 | `rtmsf_lifecycle_r1_<run>` |
| Graph 4 | `rtmsf_files_p100_f100_r1_<run>` |
| Graph 5 | `rtmsf_layout_day_first_p100_r1_<run>` (or `tenant_first`) |
| Recovery | `rtmsf_recovery_add_before_processing_r1_<run>` (one per crash case) |
| Supporting check | `rtmsf_check_short_burst_r1_<run>` (one per named check/fixture) |

Baseline tables use `crawler_` or `msck_` where applicable. The run suffix
separates reruns. Internal trial IDs in evidence records are unchanged; each
record includes its actual AWS table name.

For a small all-output run with `--sizes 100 --files 1 100
--graph4-partitions 100 --layout-sizes 100 --repetitions 1`, the runner creates
**24 new tables**: 11 comparison tables, 1 lifecycle table, 4 recovery tables,
and 8 supporting-check tables (the routing check needs two). The shared stack
also has one prototype table, created at deployment and copied for every method.
Other settings change the number of fresh tables; the main validation command
above creates 31.

Rerunning the same command creates a new execution ID, folder, table names,
measurement buckets and object prefixes. It runs fresh work; it does not append
to the previous CSV or resume an old run. Keep failed/incomplete bundles too.

At completion, the runner attempts to stop the worker and logging and remove
comparison tables/buckets and temporary crawler queues. Lifecycle, recovery and
supporting-check tables/data remain, along with shared stack resources and local
results. Inspect the recorded cleanup outcome; `--cleanup-run` retries measurement
resource cleanup without rerunning the experiment. Offline graph regeneration
uses existing CSV/outcomes and creates no AWS resources.

### Paper collection: one condition per batch

Use the same frozen source and verified image for all batches. Keep the common
profile/account/stack/region, `--request-source cloudwatch`,
`--audit-wait-seconds 600`, `--build-manifest` and `--output-dir` arguments above.
Add the following options for each batch:

| Outputs | Options | Repeat batch for | Trials per batch |
|---|---|---|---:|
| Graphs 2/3 | `--comparisons-only --sizes N --repetitions 5` | N = 100, 1000, 10000, 100000 | 15 |
| Graph 4 | `--graph4-only --graph4-partitions 10000 --files F --repetitions 5` | F = 1, 10, 100, 1000, 10000 | 10 |
| Graph 5 | `--graph5-only --layout-sizes N --repetitions 5` | N = 100, 1000, 10000 | 20 |

Use `--timeout-seconds 900 --max-minutes 240` for the initial small batches,
then assess actual setup/processing times. The 100K batch prepares 1.5 million
files; choose its budget from the preceding 10K batch's measured setup rate.
Setup itself is not interrupted at the admission deadline, so too short a budget
can leave every measurement unattempted. It is a budget, not a duration promise;
retain and investigate failed or unattempted work. A full matrix has 170
measurement trials and about 2.5 million baseline files across fresh copies.
Do not submit it as a single old pilot command.

Graph 1, recovery and supporting checks use three fresh repetitions. The full
small-validation command with `--correctness-repetitions 3 --timeout-seconds 900`
covers them alongside its selected comparison points. Use the same timeout and
metric-collection wait as the paper comparison batches so they can be assembled.
Keep its comparison data separate from the five-
repetition paper batches to avoid duplicate conditions. Preserve all evidence,
including failed attempts; do not silently replace failures with successful reruns.
Each batch generates its own CSV, plots and records. Final paper assembly must
combine the planned non-overlapping batches and retain their provenance and
failure records before rendering the complete curves.

Assemble those batches offline, listing each selected run explicitly:

```bash
uv run --frozen --extra experiment python -m experiments.assemble \
  --runs runs/REPLACE_SCALE_BATCH runs/REPLACE_FILES_BATCH runs/REPLACE_LAYOUT_BATCH \
  --correctness-run runs/REPLACE_CORRECTNESS_RUN \
  --output-dir runs/paper-results
```

Use all planned batch directories in `--runs`. `--correctness-run` takes only
Graph 1, recovery and supporting checks from the small full run, excluding its
comparison points. Omit it when the listed runs already include those outputs.
The command verifies input hashes, requires matching source/image and measurement
settings, and rejects overlapping conditions/repetitions. It never renumbers
repetitions or replaces failures. Keep a failed run instead of silently selecting
its successful rerun; investigate and record any replacement separately.
The new folder contains the combined CSV, figures and tables, plus unchanged
input bundles under `batches/` and hashes for all files. The summary lists each
batch's original status. A successful assembly means the files were combined;
check the summary and planned matrix for scientific completeness. Rerunning
requires a new output folder; existing results are never overwritten.

### Check CloudWatch request counters

To validate request instrumentation independently of the graph workloads:

```bash
uv run --frozen --extra experiment python -m experiments.aws.check_request_metrics \
  --profile "$RTMSF_PROFILE" --expected-account "$RTMSF_ACCOUNT" \
  --region "$RTMSF_REGION"
```

It creates six buckets named `rtmsf-cw-check-n<count>-r<repetition>-<run>`:
1, 10 and 100 requests per family, twice. Odd repetitions use HEAD object and
LIST V2; even repetitions use HEAD bucket and LIST V1. Multi-page cases exercise
pagination. Allow about 30 minutes for activation, requests and metric delivery.
Read `calibration.csv` in the printed evidence directory. It records expected
and observed counts, with blanks for missing data; raw request IDs, metric
snapshots, source and hashes accompany it. The command removes its temporary
buckets and metric configurations after collection. A pass verifies these
known batches, not guaranteed completeness of future CloudWatch measurements.
CloudWatch can label requests with a later minute. The bucket stays idle while
the collector includes complete minutes through `quiet_until`; the original
workload start/end remain recorded separately. Do not browse the trial bucket
or run verification reads during this interval.
Add `--list-only` to test zero HEAD/GET activity in fresh buckets. The live
control returned LIST=1 and AllRequests=1, with no HEAD/GET datapoints. Those
absent counters are inferred as observed zeros only when recorded operation
counts fully account for AllRequests, method activity exists, and no metric
read failed. Otherwise they remain unknown. Raw evidence distinguishes this
inference from an explicit zero datapoint.

After interruption, `--resume <check-directory> --cleanup-only` removes only
that check's remaining buckets without sending more test requests. Include the
same profile, account and region arguments. A cleanup receipt preserves the
original run record. The graph runner uses CloudWatch by default and retains
CloudTrail as supporting evidence.

Earlier CloudTrail HEAD/GET/LIST values are **observed lower bounds**, including recorded retries.
Calibration and a quiet collection period do not prove CloudTrail completeness.
Unavailable measurements remain blank CSV cells and gaps in figures, never
zero. A workload pass with missing request evidence becomes an incomplete
request result. Reconcile late records before making performance claims.

The required layout comparison is Graph 5, using the CSV's `layout` column.
`SUMMARY.md` records occupied prefixes; `checks_table.md` shows the short burst's
observed event, PMCP-attempt and applied-change counts.
If a budget prevents a check from running, use the selective commands below on
fresh fixtures and retain both the original outcome and the follow-up record.
Use `--checks-only duplicate_old_events rapid_changes` to rerun just those
checks on fresh fixtures. These options do not reuse earlier results.
Use `--recovery-only add_after_catalog_change` to rerun a selected crash case
with a fresh table and marker. The earlier result remains in its original run.
Use `--graph4-only` with selected `--files` values to rerun file-count comparisons
without repeating lifecycle, recovery, or the partition-count comparisons.
Use `--graph5-only` for the key-order comparison.

Regenerate all figures and tables without AWS calls, using the printed pilot
directory; the output below is a separate directory:

```bash
export RTMSF_RUN=runs/REPLACE_WITH_PRINTED_PILOT_ID
uv run --frozen --extra experiment python -m experiments.figures \
  --csv "$RTMSF_RUN/graph_data.csv" --results "$RTMSF_RUN/report_inputs.json" \
  --output-dir "${RTMSF_RUN}-regenerated"
```

## Shutdown and retained resources

The pilot attempts worker, crawler, and CloudTrail shutdown in `finally` and
records shutdown failures. Check those results and the actual task ARNs reaching
`STOPPED`. If the runner is forcibly interrupted, set the service desired
count to zero and wait for its tasks to stop before another run. Resolve its
`ClusterName`, `ServiceName`, and `TrailName` from the stack outputs; stop any
remaining trial crawler and trail logging too.

The runner removes its temporary measurement buckets, tables, and crawler queues.
The base stack, shared buckets/queues, supporting-check fixtures, ECR images, and
logs remain. Deleting the stack alone does not delete resources marked `Retain`
in the template. Remove those explicitly when you no longer need the data. The
worker has no idle compute cost after stopping; retained storage and logging can
still incur charges.

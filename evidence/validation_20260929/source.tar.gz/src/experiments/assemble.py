"""Combine non-overlapping experiment bundles and regenerate reports without AWS."""

import argparse
import csv
import hashlib
import json
from pathlib import Path
import shutil

from experiments.figures import _ordered, write_reports


def _hash(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def assemble(runs, output_dir, *, correctness_run=None):
    """Retain whole input bundles; never replace failures or renumber repetitions."""
    selected = [(Path(run).resolve(), False) for run in runs]
    if correctness_run is not None:
        selected.append((Path(correctness_run).resolve(), True))
    output = Path(output_dir).resolve()
    if not selected or output.exists():
        raise ValueError('supply runs and a new output directory')
    if len({run.name for run, _ in selected}) != len(selected):
        raise ValueError('input run names must be unique')
    if any(output.is_relative_to(run) for run, _ in selected):
        raise ValueError('output must be outside the input bundles')

    rows, recovery, checks, graph_results, batches = [], [], [], [], []
    seen, identity, common = set(), None, None
    metadata = dict(data_kind='aws_assembly', fixture_layouts={}, graphs=[], batches=batches)
    for run, correctness_only in selected:
        hashes = json.loads((run / 'artifact-hashes.json').read_text())
        required = {'graph_data.csv', 'report_inputs.json', 'manifest.json',
                    'image-build.json', 'source.tar.gz'}
        if not required <= hashes.keys():
            raise ValueError(f'{run.name}: incomplete evidence hash index')
        for name, expected in hashes.items():
            path = run / name
            if not path.resolve().is_relative_to(run) or not path.is_file() or _hash(path) != expected:
                raise ValueError(f'{run.name}: evidence hash mismatch: {name}')
        manifest = json.loads((run / 'manifest.json').read_text())
        build = json.loads((run / 'image-build.json').read_text())
        inputs = json.loads((run / 'report_inputs.json').read_text())
        source, image = manifest['source']['sha256'], build['image']
        if not source or '@sha256:' not in image:
            raise ValueError(f'{run.name}: source hash and immutable image are required')
        current_identity = (source, image)
        config = manifest['config']
        current_common = {key: config[key] for key in
                          ('region', 'expected_account', 'stack', 'request_source',
                           'timeout_seconds', 'audit_wait_seconds')}
        if identity is not None and (identity != current_identity or common != current_common):
            raise ValueError('batches must use the same source, image and measurement settings')
        identity, common = current_identity, current_common
        original = inputs['metadata']
        if original.get('data_kind') != 'aws_pilot':
            raise ValueError('assemble original AWS runs, not dummy or already assembled data')
        graphs = [1] if correctness_only else original['graphs']
        if correctness_only and 1 not in original['graphs']:
            raise ValueError('correctness run must include Graph 1')
        with (run / 'graph_data.csv').open(newline='', encoding='utf-8') as stream:
            rows.extend(row for row in csv.DictReader(stream) if int(row['graph']) in graphs)
        for group, records, target in (
            ('graph', [r for r in original['graph_results'] if r['graph'] in graphs], graph_results),
            ('recovery', inputs['recovery_results'], recovery),
            ('check', inputs['checks'], checks),
        ):
            for record in records:
                fields = ('graph', 'method', 'layout', 'x_value', 'repetition') if group == 'graph' else (
                    'case' if group == 'recovery' else 'name', 'repetition')
                key = (group, *(record.get(field) for field in fields))
                if key in seen:
                    raise ValueError(f'overlapping condition/repetition: {key}')
                seen.add(key)
                target.append({**record, 'batch': run.name})
        for key, relevant in (('graph4_partitions', 4 in graphs),
                              ('correctness_repetitions', bool(inputs['recovery_results'] or inputs['checks'] or 1 in graphs))):
            if relevant:
                value = config[key]
                if key in metadata and metadata[key] != value:
                    raise ValueError(f'incompatible {key}')
                metadata[key] = value
        metadata['graphs'] = sorted(set(metadata['graphs']) | set(graphs))
        metadata['fixture_layouts'].update({f'{run.name}/{key}': value
                                          for key, value in original.get('fixture_layouts', {}).items()})
        batches.append(dict(name=run.name, path=f'batches/{run.name}',
                            selection='correctness only' if correctness_only else 'all outputs',
                            run_status=original.get('run_status', 'incomplete_or_failed'),
                            source_hash=source, image=image,
                            artifact_index_sha256=_hash(run / 'artifact-hashes.json')))
    rows = _ordered(rows)  # Reject duplicate measurements before creating output.
    metadata.update(config=common, source_hash=identity[0], image=identity[1], graph_results=graph_results,
                    run_status='passed' if all(b['run_status'] == 'passed' for b in batches)
                    else 'incomplete_or_failed')
    output.mkdir(parents=True)
    for run, _ in selected:
        shutil.copytree(run, output / 'batches' / run.name)
    write_reports(output, rows, recovery, checks, metadata)
    hashes = {str(path.relative_to(output)): _hash(path) for path in output.rglob('*') if path.is_file()}
    (output / 'artifact-hashes.json').write_text(json.dumps(hashes, indent=2, sort_keys=True) + '\n')
    return output


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runs', nargs='+', required=True, type=Path, help='non-overlapping completed run folders, including failed runs')
    parser.add_argument('--correctness-run', type=Path, help='include only Graph 1, recovery and checks from this full validation run')
    parser.add_argument('--output-dir', required=True, type=Path, help='new combined bundle directory')
    args = parser.parse_args(argv)
    print(assemble(args.runs, args.output_dir, correctness_run=args.correctness_run))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

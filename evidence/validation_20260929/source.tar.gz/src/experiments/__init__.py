"""Bounded, inspectable workload scripts."""
